#include "performancePVNodes.h"

performancePV0Worker::performancePV0Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&measuringTerminal);
}

performancePV0Worker::~performancePV0Worker() {
  delete [] TheModelPtr;
}

double performancePV0Worker::Reward_Function(void) {

return measuringTerminal->counted->Mark();

return (0);



}

performancePV0::performancePV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&ThelineNewRJ);
  double startpts[2]={3600.0, 7200.0};
  double stoppts[2]={3600.0, 7200.0};
  Initialize("trains",(RewardType)0,2, startpts, stoppts, timeindex, 0,1, 1);
  AddVariableDependency("counted","measuringTerminal");
}

performancePV0::~performancePV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void performancePV0::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new performancePV0Worker;
}
