#ifndef _PERFORMANCE_PVS_
#define _PERFORMANCE_PVS_
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Composed/lineNew/lineNewRJ.h"
#include "Cpp/Performance_Variables/InstantOfTime.hpp"


class performancePV0Worker:public InstantOfTime
{
 public:
  measuringTerminalSAN *measuringTerminal;
  
  performancePV0Worker();
  ~performancePV0Worker();
  double Reward_Function();
};

class performancePV0:public PerformanceVariableNode
{
 public:
  lineNewRJ *ThelineNewRJ;

  performancePV0Worker *performancePV0WorkerList;

  performancePV0(int timeindex=0);
  ~performancePV0();
  void CreateWorkerList(void);
};

#endif
