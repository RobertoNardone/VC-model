#ifndef _PERFORMANCE_PVMODEL_
#define _PERFORMANCE_PVMODEL_
#include "performancePVNodes.h"
#include "Cpp/Performance_Variables/PVModel.hpp"
#include "Composed/lineNew/lineNewRJ.h"
class performancePVModel:public PVModel {
 protected:
  PerformanceVariableNode *createPVNode(int pvindex, int timeindex);
 public:
  performancePVModel(bool expandtimepoints);
};

#endif
