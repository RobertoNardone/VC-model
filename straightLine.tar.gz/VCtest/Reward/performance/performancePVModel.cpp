#include "performancePVModel.h"

performancePVModel::performancePVModel(bool expandTimeArrays) {
  TheModel=new lineNewRJ();
  DefineName("performancePVModel");
  CreatePVList(1, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* performancePVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new performancePV0(timeindex);
    break;
  }
  return NULL;
}
