#ifndef lineNewRJ__fleet_H_
#define lineNewRJ__fleet_H_
#include <math.h>
#include "Cpp/Composer/Rep.h"
#include "Cpp/Composer/AllStateVariableTypes.h"

//Submodel header files
#include "Atomic/train/trainSAN.h"

//State variable headers
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
extern Short numOfTrains;

class lineNewRJ__fleet: public Rep {
 public:
  trainSAN ** InstanceArray;

  lineNewRJ__fleet();
  ~lineNewRJ__fleet();

  // Declare new variables
  Place * globalTrainNumber;
  TrainArray * trStates;
};

#endif
