#ifndef lineNewRJ_H_
#define lineNewRJ_H_
#include <math.h>
#include "Cpp/Composer/Join.h"
#include "Cpp/Composer/AllStateVariableTypes.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/entering/enteringSAN.h"
#include "Atomic/measuringTerminal/measuringTerminalSAN.h"
#include "Atomic/ERTMSstates/ERTMSstatesSAN.h"

//State variable headers
#include "Cpp/BaseClasses/SAN/Place.h"
extern Short numOfTrains;

class lineNewRJ: public Join {
 public:
  straightSAN * straight_109_110;
  straightSAN * straight_108_109;
  straightSAN * straight_107_108;
  straightSAN * straight_106_107;
  straightSAN * straight_105_106;
  straightSAN * straight_103_104;
  straightSAN * straight_104_105;
  straightSAN * straight_102_103;
  straightSAN * straight_100_101;
  straightSAN * straight_101_102;
  enteringSAN * entering;
  measuringTerminalSAN * measuringTerminal;
  ERTMSstatesSAN * ERTMSstates;
  Place * ERTMSstate;
  Place * p100;
  Place * p101;
  Place * p102;
  Place * p103;
  Place * p104;
  Place * p105;
  Place * p106;
  Place * p107;
  Place * p108;
  Place * p109;
  Place * p110;

  lineNewRJ();
  ~lineNewRJ();
};

#endif
