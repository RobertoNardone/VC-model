#include "Composed/lineNew/lineNewRJ__fleet.h"
char * lineNewRJ__fleet__SharedNames[] = {"globalTrainNumber", "trStates"};

lineNewRJ__fleet::lineNewRJ__fleet():Rep("fleet", numOfTrains, 2, lineNewRJ__fleet__SharedNames)
{
  InstanceArray = new trainSAN * [NumModels];
  delete[] ModelArray;
  ModelArray = (BaseModelClass **) InstanceArray;
  for (counter = 0; counter < NumModels; counter++)
    InstanceArray[counter] = new trainSAN();

  SetupActions();
  if (NumModels == 0) return;

  if (AllChildrenEmpty())
    NumSharedStateVariables = 0;
  else {
    //**************** Initialize local variables ****************
    globalTrainNumber = new Place("globalTrainNumber");
    addSharedPtr(globalTrainNumber, "globalTrainNumber");
    globalTrainNumber->ShareWith(InstanceArray[0]->globalTrainNumber);

    trStates = new TrainArray("trStates");
    addSharedPtr(trStates, "trStates");
    trStates->ShareWith(InstanceArray[0]->trStates);


    //Share state in submodels
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->globalTrainNumber, globalTrainNumber);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->trStates, trStates);
    }
    for (counter = 1; counter < NumModels; counter++) {
      InstanceArray[0]->globalTrainNumber->ShareWith(InstanceArray[counter]->globalTrainNumber);
      InstanceArray[0]->trStates->ShareWith(InstanceArray[counter]->trStates);
    }
  }
  Setup("train");
}

lineNewRJ__fleet::~lineNewRJ__fleet() {
  if (NumModels == 0) return;
  delete globalTrainNumber;
  delete trStates;
  for (int i = 0; i < NumModels; i++)
    delete InstanceArray[i];
}

