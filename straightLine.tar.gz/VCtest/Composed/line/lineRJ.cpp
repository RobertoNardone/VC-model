#include "Composed/line/lineRJ.h"
char * lineRJ__SharedNames[] = {"p100", "p101", "p102", "p103", "p104", "p105", "p106", "p107", "p108", "p109", "p110", "trStates"};

lineRJ::lineRJ():Join("straigth_5km", 13, 12,lineRJ__SharedNames) {
  straight_109_110 = new straightSAN();
  ModelArray[0] = (BaseModelClass*) straight_109_110;
  ModelArray[0]->DefineName("straight_109_110");
  straight_108_109 = new straightSAN();
  ModelArray[1] = (BaseModelClass*) straight_108_109;
  ModelArray[1]->DefineName("straight_108_109");
  straight_107_108 = new straightSAN();
  ModelArray[2] = (BaseModelClass*) straight_107_108;
  ModelArray[2]->DefineName("straight_107_108");
  straight_106_107 = new straightSAN();
  ModelArray[3] = (BaseModelClass*) straight_106_107;
  ModelArray[3]->DefineName("straight_106_107");
  straight_105_106 = new straightSAN();
  ModelArray[4] = (BaseModelClass*) straight_105_106;
  ModelArray[4]->DefineName("straight_105_106");
  straight_103_104 = new straightSAN();
  ModelArray[5] = (BaseModelClass*) straight_103_104;
  ModelArray[5]->DefineName("straight_103_104");
  straight_104_105 = new straightSAN();
  ModelArray[6] = (BaseModelClass*) straight_104_105;
  ModelArray[6]->DefineName("straight_104_105");
  straight_102_103 = new straightSAN();
  ModelArray[7] = (BaseModelClass*) straight_102_103;
  ModelArray[7]->DefineName("straight_102_103");
  straight_100_101 = new straightSAN();
  ModelArray[8] = (BaseModelClass*) straight_100_101;
  ModelArray[8]->DefineName("straight_100_101");
  straight_101_102 = new straightSAN();
  ModelArray[9] = (BaseModelClass*) straight_101_102;
  ModelArray[9]->DefineName("straight_101_102");
  entering = new enteringSAN();
  ModelArray[10] = (BaseModelClass*) entering;
  ModelArray[10]->DefineName("entering");
  measuringTerminal = new measuringTerminalSAN();
  ModelArray[11] = (BaseModelClass*) measuringTerminal;
  ModelArray[11]->DefineName("measuringTerminal");
  fleet = new lineRJ__fleet();
  ModelArray[12] = (BaseModelClass*) fleet;
  ModelArray[12]->DefineName("fleet");

  SetupActions();
  if (AllChildrenEmpty())
    NumSharedStateVariables = 0;
  else {
    //**************  State sharing info  **************
    //Shared variable 0
    p100 = new Place("p100");
    addSharedPtr(p100, "p100" );
    if (straight_100_101->NumStateVariables > 0) {
      p100->ShareWith(getSharableSVPointer(straight_100_101->secIn));
      addSharingInfo(getSharableSVPointer(straight_100_101->secIn), p100, straight_100_101);
    }
    if (entering->NumStateVariables > 0) {
      p100->ShareWith(getSharableSVPointer(entering->secOut));
      addSharingInfo(getSharableSVPointer(entering->secOut), p100, entering);
    }

    //Shared variable 1
    p101 = new Place("p101");
    addSharedPtr(p101, "p101" );
    if (straight_100_101->NumStateVariables > 0) {
      p101->ShareWith(getSharableSVPointer(straight_100_101->secOut));
      addSharingInfo(getSharableSVPointer(straight_100_101->secOut), p101, straight_100_101);
    }
    if (straight_101_102->NumStateVariables > 0) {
      p101->ShareWith(getSharableSVPointer(straight_101_102->secIn));
      addSharingInfo(getSharableSVPointer(straight_101_102->secIn), p101, straight_101_102);
    }

    //Shared variable 2
    p102 = new Place("p102");
    addSharedPtr(p102, "p102" );
    if (straight_101_102->NumStateVariables > 0) {
      p102->ShareWith(getSharableSVPointer(straight_101_102->secOut));
      addSharingInfo(getSharableSVPointer(straight_101_102->secOut), p102, straight_101_102);
    }
    if (straight_102_103->NumStateVariables > 0) {
      p102->ShareWith(getSharableSVPointer(straight_102_103->secIn));
      addSharingInfo(getSharableSVPointer(straight_102_103->secIn), p102, straight_102_103);
    }

    //Shared variable 3
    p103 = new Place("p103");
    addSharedPtr(p103, "p103" );
    if (straight_102_103->NumStateVariables > 0) {
      p103->ShareWith(getSharableSVPointer(straight_102_103->secOut));
      addSharingInfo(getSharableSVPointer(straight_102_103->secOut), p103, straight_102_103);
    }
    if (straight_103_104->NumStateVariables > 0) {
      p103->ShareWith(getSharableSVPointer(straight_103_104->secIn));
      addSharingInfo(getSharableSVPointer(straight_103_104->secIn), p103, straight_103_104);
    }

    //Shared variable 4
    p104 = new Place("p104");
    addSharedPtr(p104, "p104" );
    if (straight_104_105->NumStateVariables > 0) {
      p104->ShareWith(getSharableSVPointer(straight_104_105->secIn));
      addSharingInfo(getSharableSVPointer(straight_104_105->secIn), p104, straight_104_105);
    }
    if (straight_103_104->NumStateVariables > 0) {
      p104->ShareWith(getSharableSVPointer(straight_103_104->secOut));
      addSharingInfo(getSharableSVPointer(straight_103_104->secOut), p104, straight_103_104);
    }

    //Shared variable 5
    p105 = new Place("p105");
    addSharedPtr(p105, "p105" );
    if (straight_104_105->NumStateVariables > 0) {
      p105->ShareWith(getSharableSVPointer(straight_104_105->secOut));
      addSharingInfo(getSharableSVPointer(straight_104_105->secOut), p105, straight_104_105);
    }
    if (straight_105_106->NumStateVariables > 0) {
      p105->ShareWith(getSharableSVPointer(straight_105_106->secIn));
      addSharingInfo(getSharableSVPointer(straight_105_106->secIn), p105, straight_105_106);
    }

    //Shared variable 6
    p106 = new Place("p106");
    addSharedPtr(p106, "p106" );
    if (straight_105_106->NumStateVariables > 0) {
      p106->ShareWith(getSharableSVPointer(straight_105_106->secOut));
      addSharingInfo(getSharableSVPointer(straight_105_106->secOut), p106, straight_105_106);
    }
    if (straight_106_107->NumStateVariables > 0) {
      p106->ShareWith(getSharableSVPointer(straight_106_107->secIn));
      addSharingInfo(getSharableSVPointer(straight_106_107->secIn), p106, straight_106_107);
    }

    //Shared variable 7
    p107 = new Place("p107");
    addSharedPtr(p107, "p107" );
    if (straight_106_107->NumStateVariables > 0) {
      p107->ShareWith(getSharableSVPointer(straight_106_107->secOut));
      addSharingInfo(getSharableSVPointer(straight_106_107->secOut), p107, straight_106_107);
    }
    if (straight_107_108->NumStateVariables > 0) {
      p107->ShareWith(getSharableSVPointer(straight_107_108->secIn));
      addSharingInfo(getSharableSVPointer(straight_107_108->secIn), p107, straight_107_108);
    }

    //Shared variable 8
    p108 = new Place("p108");
    addSharedPtr(p108, "p108" );
    if (straight_107_108->NumStateVariables > 0) {
      p108->ShareWith(getSharableSVPointer(straight_107_108->secOut));
      addSharingInfo(getSharableSVPointer(straight_107_108->secOut), p108, straight_107_108);
    }
    if (straight_108_109->NumStateVariables > 0) {
      p108->ShareWith(getSharableSVPointer(straight_108_109->secIn));
      addSharingInfo(getSharableSVPointer(straight_108_109->secIn), p108, straight_108_109);
    }

    //Shared variable 9
    p109 = new Place("p109");
    addSharedPtr(p109, "p109" );
    if (straight_108_109->NumStateVariables > 0) {
      p109->ShareWith(getSharableSVPointer(straight_108_109->secOut));
      addSharingInfo(getSharableSVPointer(straight_108_109->secOut), p109, straight_108_109);
    }
    if (straight_109_110->NumStateVariables > 0) {
      p109->ShareWith(getSharableSVPointer(straight_109_110->secIn));
      addSharingInfo(getSharableSVPointer(straight_109_110->secIn), p109, straight_109_110);
    }

    //Shared variable 10
    p110 = new Place("p110");
    addSharedPtr(p110, "p110" );
    if (straight_109_110->NumStateVariables > 0) {
      p110->ShareWith(getSharableSVPointer(straight_109_110->secOut));
      addSharingInfo(getSharableSVPointer(straight_109_110->secOut), p110, straight_109_110);
    }
    if (measuringTerminal->NumStateVariables > 0) {
      p110->ShareWith(getSharableSVPointer(measuringTerminal->secIn));
      addSharingInfo(getSharableSVPointer(measuringTerminal->secIn), p110, measuringTerminal);
    }

    //Shared variable 11
    trStates = new TrainArray("trStates");
    addSharedPtr(trStates, "trStates" );
    if (straight_109_110->NumStateVariables > 0) {
      trStates->ShareWith(getSharableSVPointer(straight_109_110->trStates));
      addSharingInfo(getSharableSVPointer(straight_109_110->trStates), trStates, straight_109_110);
    }
    if (straight_108_109->NumStateVariables > 0) {
      trStates->ShareWith(getSharableSVPointer(straight_108_109->trStates));
      addSharingInfo(getSharableSVPointer(straight_108_109->trStates), trStates, straight_108_109);
    }
    if (straight_107_108->NumStateVariables > 0) {
      trStates->ShareWith(getSharableSVPointer(straight_107_108->trStates));
      addSharingInfo(getSharableSVPointer(straight_107_108->trStates), trStates, straight_107_108);
    }
    if (straight_106_107->NumStateVariables > 0) {
      trStates->ShareWith(getSharableSVPointer(straight_106_107->trStates));
      addSharingInfo(getSharableSVPointer(straight_106_107->trStates), trStates, straight_106_107);
    }
    if (straight_105_106->NumStateVariables > 0) {
      trStates->ShareWith(getSharableSVPointer(straight_105_106->trStates));
      addSharingInfo(getSharableSVPointer(straight_105_106->trStates), trStates, straight_105_106);
    }
    if (straight_103_104->NumStateVariables > 0) {
      trStates->ShareWith(getSharableSVPointer(straight_103_104->trStates));
      addSharingInfo(getSharableSVPointer(straight_103_104->trStates), trStates, straight_103_104);
    }
    if (straight_104_105->NumStateVariables > 0) {
      trStates->ShareWith(getSharableSVPointer(straight_104_105->trStates));
      addSharingInfo(getSharableSVPointer(straight_104_105->trStates), trStates, straight_104_105);
    }
    if (straight_102_103->NumStateVariables > 0) {
      trStates->ShareWith(getSharableSVPointer(straight_102_103->trStates));
      addSharingInfo(getSharableSVPointer(straight_102_103->trStates), trStates, straight_102_103);
    }
    if (straight_100_101->NumStateVariables > 0) {
      trStates->ShareWith(getSharableSVPointer(straight_100_101->trStates));
      addSharingInfo(getSharableSVPointer(straight_100_101->trStates), trStates, straight_100_101);
    }
    if (straight_101_102->NumStateVariables > 0) {
      trStates->ShareWith(getSharableSVPointer(straight_101_102->trStates));
      addSharingInfo(getSharableSVPointer(straight_101_102->trStates), trStates, straight_101_102);
    }
    if (fleet->NumStateVariables > 0) {
      trStates->ShareWith(getSharableSVPointer(fleet->trStates));
      addSharingInfo(getSharableSVPointer(fleet->trStates), trStates, fleet);
    }

  }

  Setup();
}

lineRJ::~lineRJ() {
  if (!AllChildrenEmpty()) {
    delete p100;
    delete p101;
    delete p102;
    delete p103;
    delete p104;
    delete p105;
    delete p106;
    delete p107;
    delete p108;
    delete p109;
    delete p110;
    delete trStates;
  }
  delete straight_109_110;
  delete straight_108_109;
  delete straight_107_108;
  delete straight_106_107;
  delete straight_105_106;
  delete straight_103_104;
  delete straight_104_105;
  delete straight_102_103;
  delete straight_100_101;
  delete straight_101_102;
  delete entering;
  delete measuringTerminal;
  delete fleet;
}
