#ifndef lineRJ_H_
#define lineRJ_H_
#include <math.h>
#include "Cpp/Composer/Join.h"
#include "Cpp/Composer/AllStateVariableTypes.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/straight/straightSAN.h"
#include "Atomic/entering/enteringSAN.h"
#include "Atomic/measuringTerminal/measuringTerminalSAN.h"
#include "Composed/line/lineRJ__fleet.h"

//State variable headers
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
extern Short numOfTrains;

class lineRJ: public Join {
 public:
  straightSAN * straight_109_110;
  straightSAN * straight_108_109;
  straightSAN * straight_107_108;
  straightSAN * straight_106_107;
  straightSAN * straight_105_106;
  straightSAN * straight_103_104;
  straightSAN * straight_104_105;
  straightSAN * straight_102_103;
  straightSAN * straight_100_101;
  straightSAN * straight_101_102;
  enteringSAN * entering;
  measuringTerminalSAN * measuringTerminal;
  lineRJ__fleet * fleet;
  Place * p100;
  Place * p101;
  Place * p102;
  Place * p103;
  Place * p104;
  Place * p105;
  Place * p106;
  Place * p107;
  Place * p108;
  Place * p109;
  Place * p110;
  TrainArray * trStates;

  lineRJ();
  ~lineRJ();
};

#endif
