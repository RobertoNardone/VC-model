#ifndef lineRJ__fleet_H_
#define lineRJ__fleet_H_
#include <math.h>
#include "Cpp/Composer/Rep.h"
#include "Cpp/Composer/AllStateVariableTypes.h"

//Submodel header files
#include "Atomic/train/trainSAN.h"

//State variable headers
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
extern Short numOfTrains;

class lineRJ__fleet: public Rep {
 public:
  trainSAN ** InstanceArray;

  lineRJ__fleet();
  ~lineRJ__fleet();

  // Declare new variables
  Place * globalTrainNumber;
  TrainArray * trStates;
};

#endif
