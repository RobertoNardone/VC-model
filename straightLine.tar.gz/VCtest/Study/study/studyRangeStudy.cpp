
#include "Study/study/studyRangeStudy.h"

//******************************************************
//Global Variables
//******************************************************
Short FSDelay;
Double fs2fsvcRateH;
Double fs2psRateH;
Double fsvc2fsRateH;
Short numOfTrains;
Double repairRateH;
Short trainLength;

//********************************************************
//studyRangeStudy Constructor
//********************************************************
studyRangeStudy::studyRangeStudy() {

  // define arrays of global variable names and types
  NumGVs = 7;
  NumExps = 10;

  GVNames = new char*[NumGVs];
  GVTypes = new char*[NumGVs];
  GVNames[0]=strdup("FSDelay");
  GVTypes[0]=strdup("short");
  GVNames[1]=strdup("fs2fsvcRateH");
  GVTypes[1]=strdup("double");
  GVNames[2]=strdup("fs2psRateH");
  GVTypes[2]=strdup("double");
  GVNames[3]=strdup("fsvc2fsRateH");
  GVTypes[3]=strdup("double");
  GVNames[4]=strdup("numOfTrains");
  GVTypes[4]=strdup("short");
  GVNames[5]=strdup("repairRateH");
  GVTypes[5]=strdup("double");
  GVNames[6]=strdup("trainLength");
  GVTypes[6]=strdup("short");

  // create the arrays to store the values of each gv
  FSDelayValues = new short[NumExps];
  fs2fsvcRateHValues = new double[NumExps];
  fs2psRateHValues = new double[NumExps];
  fsvc2fsRateHValues = new double[NumExps];
  numOfTrainsValues = new short[NumExps];
  repairRateHValues = new double[NumExps];
  trainLengthValues = new short[NumExps];

  // call methods to assign values to each gv
  SetValues_FSDelay();
  SetValues_fs2fsvcRateH();
  SetValues_fs2psRateH();
  SetValues_fsvc2fsRateH();
  SetValues_numOfTrains();
  SetValues_repairRateH();
  SetValues_trainLength();
  SetDefaultMobiusRoot(MOBIUSROOT);
}


//******************************************************
//studyRangeStudy Destructor
//******************************************************
studyRangeStudy::~studyRangeStudy() {
  delete [] FSDelayValues;
  delete [] fs2fsvcRateHValues;
  delete [] fs2psRateHValues;
  delete [] fsvc2fsRateHValues;
  delete [] numOfTrainsValues;
  delete [] repairRateHValues;
  delete [] trainLengthValues;
  delete ThePVModel;
}


//******************************************************
// set values for FSDelay
//******************************************************
void studyRangeStudy::SetValues_FSDelay() {
  FSDelayValues[0] = 24;
  FSDelayValues[1] = 24;
  FSDelayValues[2] = 24;
  FSDelayValues[3] = 24;
  FSDelayValues[4] = 24;
  FSDelayValues[5] = 24;
  FSDelayValues[6] = 24;
  FSDelayValues[7] = 24;
  FSDelayValues[8] = 24;
  FSDelayValues[9] = 24;
}


//******************************************************
// set values for fs2fsvcRateH
//******************************************************
void studyRangeStudy::SetValues_fs2fsvcRateH() {
  fs2fsvcRateHValues[0] = 0.5;
  fs2fsvcRateHValues[1] = 0.5;
  fs2fsvcRateHValues[2] = 0.5;
  fs2fsvcRateHValues[3] = 0.5;
  fs2fsvcRateHValues[4] = 0.5;
  fs2fsvcRateHValues[5] = 0.5;
  fs2fsvcRateHValues[6] = 0.5;
  fs2fsvcRateHValues[7] = 0.5;
  fs2fsvcRateHValues[8] = 0.5;
  fs2fsvcRateHValues[9] = 0.5;
}


//******************************************************
// set values for fs2psRateH
//******************************************************
void studyRangeStudy::SetValues_fs2psRateH() {
  fs2psRateHValues[0] = 0.1;
  fs2psRateHValues[1] = 0.1;
  fs2psRateHValues[2] = 0.1;
  fs2psRateHValues[3] = 0.1;
  fs2psRateHValues[4] = 0.1;
  fs2psRateHValues[5] = 0.1;
  fs2psRateHValues[6] = 0.1;
  fs2psRateHValues[7] = 0.1;
  fs2psRateHValues[8] = 0.1;
  fs2psRateHValues[9] = 0.1;
}


//******************************************************
// set values for fsvc2fsRateH
//******************************************************
void studyRangeStudy::SetValues_fsvc2fsRateH() {
  fsvc2fsRateHValues[0] = 0.1;
  fsvc2fsRateHValues[1] = 0.2;
  fsvc2fsRateHValues[2] = 0.30000000000000004;
  fsvc2fsRateHValues[3] = 0.4;
  fsvc2fsRateHValues[4] = 0.5;
  fsvc2fsRateHValues[5] = 0.6;
  fsvc2fsRateHValues[6] = 0.7;
  fsvc2fsRateHValues[7] = 0.7999999999999999;
  fsvc2fsRateHValues[8] = 0.8999999999999999;
  fsvc2fsRateHValues[9] = 0.9999999999999999;
}


//******************************************************
// set values for numOfTrains
//******************************************************
void studyRangeStudy::SetValues_numOfTrains() {
  numOfTrainsValues[0] = 20;
  numOfTrainsValues[1] = 20;
  numOfTrainsValues[2] = 20;
  numOfTrainsValues[3] = 20;
  numOfTrainsValues[4] = 20;
  numOfTrainsValues[5] = 20;
  numOfTrainsValues[6] = 20;
  numOfTrainsValues[7] = 20;
  numOfTrainsValues[8] = 20;
  numOfTrainsValues[9] = 20;
}


//******************************************************
// set values for repairRateH
//******************************************************
void studyRangeStudy::SetValues_repairRateH() {
  repairRateHValues[0] = 2.0;
  repairRateHValues[1] = 2.0;
  repairRateHValues[2] = 2.0;
  repairRateHValues[3] = 2.0;
  repairRateHValues[4] = 2.0;
  repairRateHValues[5] = 2.0;
  repairRateHValues[6] = 2.0;
  repairRateHValues[7] = 2.0;
  repairRateHValues[8] = 2.0;
  repairRateHValues[9] = 2.0;
}


//******************************************************
// set values for trainLength
//******************************************************
void studyRangeStudy::SetValues_trainLength() {
  trainLengthValues[0] = 2;
  trainLengthValues[1] = 2;
  trainLengthValues[2] = 2;
  trainLengthValues[3] = 2;
  trainLengthValues[4] = 2;
  trainLengthValues[5] = 2;
  trainLengthValues[6] = 2;
  trainLengthValues[7] = 2;
  trainLengthValues[8] = 2;
  trainLengthValues[9] = 2;
}



//******************************************************
//print values of gv (for debugging)
//******************************************************
void studyRangeStudy::PrintGlobalValues(int expNum) {
  if (NumGVs == 0) {
    cout<<"There are no global variables."<<endl;
    return;
  }

  SetGVs(expNum);

  cout<<"The Global Variable values for experiment "<<
    GetExpName(expNum)<<" are:"<<endl;
  cout << "FSDelay\tshort\t" << FSDelay << endl;
  cout << "fs2fsvcRateH\tdouble\t" << fs2fsvcRateH << endl;
  cout << "fs2psRateH\tdouble\t" << fs2psRateH << endl;
  cout << "fsvc2fsRateH\tdouble\t" << fsvc2fsRateH << endl;
  cout << "numOfTrains\tshort\t" << numOfTrains << endl;
  cout << "repairRateH\tdouble\t" << repairRateH << endl;
  cout << "trainLength\tshort\t" << trainLength << endl;
}


//******************************************************
//retrieve the value of a global variable
//******************************************************
void *studyRangeStudy::GetGVValue(char *TheGVName) {
  if (strcmp("FSDelay", TheGVName) == 0)
    return &FSDelay;
  else if (strcmp("fs2fsvcRateH", TheGVName) == 0)
    return &fs2fsvcRateH;
  else if (strcmp("fs2psRateH", TheGVName) == 0)
    return &fs2psRateH;
  else if (strcmp("fsvc2fsRateH", TheGVName) == 0)
    return &fsvc2fsRateH;
  else if (strcmp("numOfTrains", TheGVName) == 0)
    return &numOfTrains;
  else if (strcmp("repairRateH", TheGVName) == 0)
    return &repairRateH;
  else if (strcmp("trainLength", TheGVName) == 0)
    return &trainLength;
  else 
    cerr<<"!! studyRangeStudy::GetGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
  return NULL;
}


//******************************************************
//override the value of a global variable
//******************************************************
void studyRangeStudy::OverrideGVValue(char *TheGVName,void *TheGVValue) {
  if (strcmp("FSDelay", TheGVName) == 0)
    SetGvValue(FSDelay, *(short *)TheGVValue);
  else if (strcmp("fs2fsvcRateH", TheGVName) == 0)
    SetGvValue(fs2fsvcRateH, *(double *)TheGVValue);
  else if (strcmp("fs2psRateH", TheGVName) == 0)
    SetGvValue(fs2psRateH, *(double *)TheGVValue);
  else if (strcmp("fsvc2fsRateH", TheGVName) == 0)
    SetGvValue(fsvc2fsRateH, *(double *)TheGVValue);
  else if (strcmp("numOfTrains", TheGVName) == 0)
    SetGvValue(numOfTrains, *(short *)TheGVValue);
  else if (strcmp("repairRateH", TheGVName) == 0)
    SetGvValue(repairRateH, *(double *)TheGVValue);
  else if (strcmp("trainLength", TheGVName) == 0)
    SetGvValue(trainLength, *(short *)TheGVValue);
  else 
    cerr<<"!! studyRangeStudy::OverrideGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
}


//******************************************************
//set the value of all global variables to the given exp
//******************************************************
void studyRangeStudy::SetGVs(int expNum) {
  SetGvValue(FSDelay, FSDelayValues[expNum]);
  SetGvValue(fs2fsvcRateH, fs2fsvcRateHValues[expNum]);
  SetGvValue(fs2psRateH, fs2psRateHValues[expNum]);
  SetGvValue(fsvc2fsRateH, fsvc2fsRateHValues[expNum]);
  SetGvValue(numOfTrains, numOfTrainsValues[expNum]);
  SetGvValue(repairRateH, repairRateHValues[expNum]);
  SetGvValue(trainLength, trainLengthValues[expNum]);
}


//******************************************************
//static class method called by solvers to create study 
//(and thus create all of the model)
//******************************************************
BaseStudyClass* GlobalStudyPtr = NULL;
BaseStudyClass * GenerateStudy() {
  if (GlobalStudyPtr == NULL)
    GlobalStudyPtr = new studyRangeStudy();
  return GlobalStudyPtr;
}

void DestructStudy() {
  delete GlobalStudyPtr;
  GlobalStudyPtr = NULL;
}
//******************************************************
//get and create the PVModel
//******************************************************
PVModel* studyRangeStudy::GetPVModel(bool expandTimeArrays) {
  if (ThePVModel!=NULL)
    delete ThePVModel;
  // create the PV model
  ThePVModel=new performancePVModel(expandTimeArrays);
  return ThePVModel;
}


