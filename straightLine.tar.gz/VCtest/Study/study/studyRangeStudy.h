
#ifndef studyRangeSTUDY_H_
#define studyRangeSTUDY_H_

#include "Reward/performance/performancePVNodes.h"
#include "Reward/performance/performancePVModel.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/Study/BaseStudyClass.hpp"

extern Short FSDelay;
extern Double fs2fsvcRateH;
extern Double fs2psRateH;
extern Double fsvc2fsRateH;
extern Short numOfTrains;
extern Double repairRateH;
extern Short trainLength;

class studyRangeStudy : public BaseStudyClass {
public:

studyRangeStudy();
~studyRangeStudy();

private:

short *FSDelayValues;
double *fs2fsvcRateHValues;
double *fs2psRateHValues;
double *fsvc2fsRateHValues;
short *numOfTrainsValues;
double *repairRateHValues;
short *trainLengthValues;

void SetValues_FSDelay();
void SetValues_fs2fsvcRateH();
void SetValues_fs2psRateH();
void SetValues_fsvc2fsRateH();
void SetValues_numOfTrains();
void SetValues_repairRateH();
void SetValues_trainLength();

void PrintGlobalValues(int);
void *GetGVValue(char *TheGVName);
void OverrideGVValue(char *TheGVName, void *TheGVValue);
void SetGVs(int expnum);
PVModel *GetPVModel(bool expandTimeArrays);
};

#endif

