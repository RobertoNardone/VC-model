#ifndef measuringTerminalSAN_H_
#define measuringTerminalSAN_H_

#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern UserDistributions* TheDistribution;

void MemoryError();


/*********************************************************************
               measuringTerminalSAN Submodel Definition                   
*********************************************************************/

class measuringTerminalSAN:public SANModel{
public:

class countingActivity:public Activity {
public:

  ExtendedPlace<short>* secIn;
  ExtendedPlace<short>* counter_LastId;
  ExtendedPlace<int>* counted;

  double* TheDistributionParameters;
  countingActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // countingActivityActivity

  //List of user-specified place names
  ExtendedPlace<short>* counter_LastId;
  ExtendedPlace<short>* secIn;
  ExtendedPlace<int>* counted;

  // Create instances of all actvities
  countingActivity counting;
  //Create instances of all groups 
  PreselectGroup ImmediateGroup;
  PostselectGroup countingGroup;

  measuringTerminalSAN();
  ~measuringTerminalSAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end measuringTerminalSAN

#endif // measuringTerminalSAN_H_
