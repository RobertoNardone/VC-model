

// This C++ file was created by SanEditor

#include "Atomic/measuringTerminal/measuringTerminalSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         measuringTerminalSAN Constructor             
******************************************************************/


measuringTerminalSAN::measuringTerminalSAN(){


  Activity* InitialActionList[1]={
    &counting  // 0
  };

  BaseGroupClass* InitialGroupList[1]={
    (BaseGroupClass*) &(counting)
  };

  short temp_counter_LastIdshort = 0;
  counter_LastId = new ExtendedPlace<short>("counter_LastId",temp_counter_LastIdshort);
  short temp_secInshort = 0;
  secIn = new ExtendedPlace<short>("secIn",temp_secInshort);
  int temp_countedint = 0;
  counted = new ExtendedPlace<int>("counted",temp_countedint);
  BaseStateVariableClass* InitialPlaces[3]={
    counter_LastId,  // 0
    secIn,  // 1
    counted   // 2
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("measuringTerminal", 3, InitialPlaces, 
                        0, InitialROPlaces, 
                        1, InitialActionList, 1, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[3][2]={ 
    {1,0}, {0,0}, {2,0}
  };
  for(int n=0;n<3;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[1][2]={ 
    {1,0}
  };
  for(int n=0;n<1;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<1;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void measuringTerminalSAN::CustomInitialization() {

}
measuringTerminalSAN::~measuringTerminalSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void measuringTerminalSAN::assignPlacesToActivitiesInst(){
  counting.secIn = (ExtendedPlace<short>*) LocalStateVariables[1];
  counting.counter_LastId = (ExtendedPlace<short>*) LocalStateVariables[0];
  counting.counted = (ExtendedPlace<int>*) LocalStateVariables[2];
}
void measuringTerminalSAN::assignPlacesToActivitiesTimed(){
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================countingActivity========================*/


measuringTerminalSAN::countingActivity::countingActivity(){
  ActivityInitialize("counting",0,Instantaneous , RaceEnabled, 3,1, false);
}

void measuringTerminalSAN::countingActivity::LinkVariables(){



}

bool measuringTerminalSAN::countingActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((secIn->Mark()>0));
  return NewEnabled;
}

double measuringTerminalSAN::countingActivity::Weight(){ 
  return 1;
}

bool measuringTerminalSAN::countingActivity::ReactivationPredicate(){ 
  return false;
}

bool measuringTerminalSAN::countingActivity::ReactivationFunction(){ 
  return false;
}

double measuringTerminalSAN::countingActivity::SampleDistribution(){
  return 0;
}

double* measuringTerminalSAN::countingActivity::ReturnDistributionParameters(){
    return NULL;
}

int measuringTerminalSAN::countingActivity::Rank(){
  return 1;
}

BaseActionClass* measuringTerminalSAN::countingActivity::Fire(){
  if(secIn->Mark()!=counter_LastId->Mark()) {
	counter_LastId->Mark()=secIn->Mark();
	counted->Mark()++;
}
secIn->Mark()=0;
  return this;
}

