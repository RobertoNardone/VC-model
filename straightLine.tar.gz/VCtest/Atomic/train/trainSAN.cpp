

// This C++ file was created by SanEditor

#include "Atomic/train/trainSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         trainSAN Constructor             
******************************************************************/


trainSAN::trainSAN(){


  Activity* InitialActionList[6]={
    &assignId, //0
    &fsvc2fs, //1
    &fs2fsvc, //2
    &fsvc2ps, //3
    &fs2ps, //4
    &repair  // 5
  };

  BaseGroupClass* InitialGroupList[6]={
    (BaseGroupClass*) &(fsvc2fs), 
    (BaseGroupClass*) &(fs2fsvc), 
    (BaseGroupClass*) &(fsvc2ps), 
    (BaseGroupClass*) &(fs2ps), 
    (BaseGroupClass*) &(repair), 
    (BaseGroupClass*) &(assignId)
  };

  assign = new Place("assign" ,1);
  FSVC = new Place("FSVC" ,0);
  FS = new Place("FS" ,0);
  PS = new Place("PS" ,0);
  short temp_globalTrainNumbershort = 0;
  globalTrainNumber = new ExtendedPlace<short>("globalTrainNumber",temp_globalTrainNumbershort);
  short temp_idshort = 0;
  id = new ExtendedPlace<short>("id",temp_idshort);
  short temp_trStatesTrainArrayvalue = 0;
  trStates = new TrainArray("trStates",temp_trStatesTrainArrayvalue);
  BaseStateVariableClass* InitialPlaces[7]={
    assign,  // 0
    FSVC,  // 1
    FS,  // 2
    PS,  // 3
    globalTrainNumber,  // 4
    id,  // 5
    trStates   // 6
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("train", 7, InitialPlaces, 
                        0, InitialROPlaces, 
                        6, InitialActionList, 6, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[25][2]={ 
    {0,0}, {1,0}, {5,0}, {4,0}, {6,0}, {1,1}, {2,1}, {5,1}, {6,1}, 
    {2,2}, {1,2}, {5,2}, {6,2}, {1,3}, {3,3}, {5,3}, {6,3}, {2,4}, 
    {3,4}, {5,4}, {6,4}, {3,5}, {2,5}, {5,5}, {6,5}
  };
  for(int n=0;n<25;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[6][2]={ 
    {0,0}, {1,1}, {2,2}, {1,3}, {2,4}, {3,5}
  };
  for(int n=0;n<6;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<6;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void trainSAN::CustomInitialization() {

}
trainSAN::~trainSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void trainSAN::assignPlacesToActivitiesInst(){
  assignId.assign = (Place*) LocalStateVariables[0];
  assignId.FSVC = (Place*) LocalStateVariables[1];
  assignId.id = (ExtendedPlace<short>*) LocalStateVariables[5];
  assignId.globalTrainNumber = (ExtendedPlace<short>*) LocalStateVariables[4];
  assignId.trStates = (TrainArray*) LocalStateVariables[6];
}
void trainSAN::assignPlacesToActivitiesTimed(){
  fsvc2fs.FSVC = (Place*) LocalStateVariables[1];
  fsvc2fs.FS = (Place*) LocalStateVariables[2];
  fsvc2fs.id = (ExtendedPlace<short>*) LocalStateVariables[5];
  fsvc2fs.trStates = (TrainArray*) LocalStateVariables[6];
  fs2fsvc.FS = (Place*) LocalStateVariables[2];
  fs2fsvc.FSVC = (Place*) LocalStateVariables[1];
  fs2fsvc.id = (ExtendedPlace<short>*) LocalStateVariables[5];
  fs2fsvc.trStates = (TrainArray*) LocalStateVariables[6];
  fsvc2ps.FSVC = (Place*) LocalStateVariables[1];
  fsvc2ps.PS = (Place*) LocalStateVariables[3];
  fsvc2ps.id = (ExtendedPlace<short>*) LocalStateVariables[5];
  fsvc2ps.trStates = (TrainArray*) LocalStateVariables[6];
  fs2ps.FS = (Place*) LocalStateVariables[2];
  fs2ps.PS = (Place*) LocalStateVariables[3];
  fs2ps.id = (ExtendedPlace<short>*) LocalStateVariables[5];
  fs2ps.trStates = (TrainArray*) LocalStateVariables[6];
  repair.PS = (Place*) LocalStateVariables[3];
  repair.FS = (Place*) LocalStateVariables[2];
  repair.id = (ExtendedPlace<short>*) LocalStateVariables[5];
  repair.trStates = (TrainArray*) LocalStateVariables[6];
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================assignIdActivity========================*/


trainSAN::assignIdActivity::assignIdActivity(){
  ActivityInitialize("assignId",5,Instantaneous , RaceEnabled, 5,1, false);
}

void trainSAN::assignIdActivity::LinkVariables(){
  assign->Register(&assign_Mobius_Mark);
  FSVC->Register(&FSVC_Mobius_Mark);



}

bool trainSAN::assignIdActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(assign_Mobius_Mark)) >=1));
  return NewEnabled;
}

double trainSAN::assignIdActivity::Weight(){ 
  return 1;
}

bool trainSAN::assignIdActivity::ReactivationPredicate(){ 
  return false;
}

bool trainSAN::assignIdActivity::ReactivationFunction(){ 
  return false;
}

double trainSAN::assignIdActivity::SampleDistribution(){
  return 0;
}

double* trainSAN::assignIdActivity::ReturnDistributionParameters(){
    return NULL;
}

int trainSAN::assignIdActivity::Rank(){
  return 1;
}

BaseActionClass* trainSAN::assignIdActivity::Fire(){
  (*(assign_Mobius_Mark))--;
  id->Mark()=globalTrainNumber->Mark()++;
  trStates->Index(id->Mark())->Mark()=1;
  (*(FSVC_Mobius_Mark))++;
  return this;
}

/*======================fsvc2fsActivity========================*/

trainSAN::fsvc2fsActivity::fsvc2fsActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("fsvc2fs",0,Exponential, RaceEnabled, 4,1, false);
}

trainSAN::fsvc2fsActivity::~fsvc2fsActivity(){
  delete[] TheDistributionParameters;
}

void trainSAN::fsvc2fsActivity::LinkVariables(){
  FSVC->Register(&FSVC_Mobius_Mark);
  FS->Register(&FS_Mobius_Mark);


}

bool trainSAN::fsvc2fsActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(FSVC_Mobius_Mark)) >=1));
  return NewEnabled;
}

double trainSAN::fsvc2fsActivity::Rate(){
  return (double) fsvc2fsRateH/3600.0;
  return 1.0;  // default rate if none is specified
}

double trainSAN::fsvc2fsActivity::Weight(){ 
  return 1;
}

bool trainSAN::fsvc2fsActivity::ReactivationPredicate(){ 
  return false;
}

bool trainSAN::fsvc2fsActivity::ReactivationFunction(){ 
  return false;
}

double trainSAN::fsvc2fsActivity::SampleDistribution(){
  return TheDistribution->Exponential( (double) fsvc2fsRateH/3600.0);
}

double* trainSAN::fsvc2fsActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int trainSAN::fsvc2fsActivity::Rank(){
  return 1;
}

BaseActionClass* trainSAN::fsvc2fsActivity::Fire(){
  (*(FSVC_Mobius_Mark))--;
  trStates->Index(id->Mark())->Mark()=2;
  (*(FS_Mobius_Mark))++;
  return this;
}

/*======================fs2fsvcActivity========================*/

trainSAN::fs2fsvcActivity::fs2fsvcActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("fs2fsvc",1,Exponential, RaceEnabled, 4,1, false);
}

trainSAN::fs2fsvcActivity::~fs2fsvcActivity(){
  delete[] TheDistributionParameters;
}

void trainSAN::fs2fsvcActivity::LinkVariables(){
  FS->Register(&FS_Mobius_Mark);
  FSVC->Register(&FSVC_Mobius_Mark);


}

bool trainSAN::fs2fsvcActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(FS_Mobius_Mark)) >=1));
  return NewEnabled;
}

double trainSAN::fs2fsvcActivity::Rate(){
  return (double) fs2fsvcRateH/3600.0;
  return 1.0;  // default rate if none is specified
}

double trainSAN::fs2fsvcActivity::Weight(){ 
  return 1;
}

bool trainSAN::fs2fsvcActivity::ReactivationPredicate(){ 
  return false;
}

bool trainSAN::fs2fsvcActivity::ReactivationFunction(){ 
  return false;
}

double trainSAN::fs2fsvcActivity::SampleDistribution(){
  return TheDistribution->Exponential( (double) fs2fsvcRateH/3600.0);
}

double* trainSAN::fs2fsvcActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int trainSAN::fs2fsvcActivity::Rank(){
  return 1;
}

BaseActionClass* trainSAN::fs2fsvcActivity::Fire(){
  (*(FS_Mobius_Mark))--;
  trStates->Index(id->Mark())->Mark()=1;
  (*(FSVC_Mobius_Mark))++;
  return this;
}

/*======================fsvc2psActivity========================*/

trainSAN::fsvc2psActivity::fsvc2psActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("fsvc2ps",2,Exponential, RaceEnabled, 4,1, false);
}

trainSAN::fsvc2psActivity::~fsvc2psActivity(){
  delete[] TheDistributionParameters;
}

void trainSAN::fsvc2psActivity::LinkVariables(){
  FSVC->Register(&FSVC_Mobius_Mark);
  PS->Register(&PS_Mobius_Mark);


}

bool trainSAN::fsvc2psActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(FSVC_Mobius_Mark)) >=1));
  return NewEnabled;
}

double trainSAN::fsvc2psActivity::Rate(){
  return (double) fs2psRateH/3600.0;
  return 1.0;  // default rate if none is specified
}

double trainSAN::fsvc2psActivity::Weight(){ 
  return 1;
}

bool trainSAN::fsvc2psActivity::ReactivationPredicate(){ 
  return false;
}

bool trainSAN::fsvc2psActivity::ReactivationFunction(){ 
  return false;
}

double trainSAN::fsvc2psActivity::SampleDistribution(){
  return TheDistribution->Exponential( (double) fs2psRateH/3600.0);
}

double* trainSAN::fsvc2psActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int trainSAN::fsvc2psActivity::Rank(){
  return 1;
}

BaseActionClass* trainSAN::fsvc2psActivity::Fire(){
  (*(FSVC_Mobius_Mark))--;
  trStates->Index(id->Mark())->Mark()=3;
  (*(PS_Mobius_Mark))++;
  return this;
}

/*======================fs2psActivity========================*/

trainSAN::fs2psActivity::fs2psActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("fs2ps",3,Exponential, RaceEnabled, 4,1, false);
}

trainSAN::fs2psActivity::~fs2psActivity(){
  delete[] TheDistributionParameters;
}

void trainSAN::fs2psActivity::LinkVariables(){
  FS->Register(&FS_Mobius_Mark);
  PS->Register(&PS_Mobius_Mark);


}

bool trainSAN::fs2psActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(FS_Mobius_Mark)) >=1));
  return NewEnabled;
}

double trainSAN::fs2psActivity::Rate(){
  return fs2psRateH/3600.0;
  return 1.0;  // default rate if none is specified
}

double trainSAN::fs2psActivity::Weight(){ 
  return 1;
}

bool trainSAN::fs2psActivity::ReactivationPredicate(){ 
  return false;
}

bool trainSAN::fs2psActivity::ReactivationFunction(){ 
  return false;
}

double trainSAN::fs2psActivity::SampleDistribution(){
  return TheDistribution->Exponential( fs2psRateH/3600.0);
}

double* trainSAN::fs2psActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int trainSAN::fs2psActivity::Rank(){
  return 1;
}

BaseActionClass* trainSAN::fs2psActivity::Fire(){
  (*(FS_Mobius_Mark))--;
  trStates->Index(id->Mark())->Mark()=3;
  (*(PS_Mobius_Mark))++;
  return this;
}

/*======================repairActivity========================*/

trainSAN::repairActivity::repairActivity(){
  TheDistributionParameters = new double[2];
  ActivityInitialize("repair",4,Normal, RaceEnabled, 4,1, false);
}

trainSAN::repairActivity::~repairActivity(){
  delete[] TheDistributionParameters;
}

void trainSAN::repairActivity::LinkVariables(){
  PS->Register(&PS_Mobius_Mark);
  FS->Register(&FS_Mobius_Mark);


}

bool trainSAN::repairActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(PS_Mobius_Mark)) >=1));
  return NewEnabled;
}

double trainSAN::repairActivity::NormalParamMean(){
  return repairRateH*3600.0;
  return 1.0;  // default rate if none is specified
}

double trainSAN::repairActivity::NormalParamVariance(){
  return 100;
  return 1.0;  // default rate if none is specified
}

double trainSAN::repairActivity::Weight(){ 
  return 1;
}

bool trainSAN::repairActivity::ReactivationPredicate(){ 
  return false;
}

bool trainSAN::repairActivity::ReactivationFunction(){ 
  return false;
}

double trainSAN::repairActivity::SampleDistribution(){
  return TheDistribution->Normal( repairRateH*3600.0,  100);
}

double* trainSAN::repairActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = NormalParamMean();
  TheDistributionParameters[1] = NormalParamVariance();
  return TheDistributionParameters;
}

int trainSAN::repairActivity::Rank(){
  return 1;
}

BaseActionClass* trainSAN::repairActivity::Fire(){
  (*(PS_Mobius_Mark))--;
  trStates->Index(id->Mark())->Mark()=2;
  (*(FS_Mobius_Mark))++;
  return this;
}

