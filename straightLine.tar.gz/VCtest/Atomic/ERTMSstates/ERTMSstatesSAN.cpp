

// This C++ file was created by SanEditor

#include "Atomic/ERTMSstates/ERTMSstatesSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         ERTMSstatesSAN Constructor             
******************************************************************/


ERTMSstatesSAN::ERTMSstatesSAN(){


  Activity* InitialActionList[5]={
    &fsvc2fs, //0
    &fs2fsvc, //1
    &fsvc2ps, //2
    &fs2ps, //3
    &repair  // 4
  };

  BaseGroupClass* InitialGroupList[5]={
    (BaseGroupClass*) &(fsvc2fs), 
    (BaseGroupClass*) &(fs2fsvc), 
    (BaseGroupClass*) &(fsvc2ps), 
    (BaseGroupClass*) &(fs2ps), 
    (BaseGroupClass*) &(repair)
  };

  FSVC = new Place("FSVC" ,1);
  FS = new Place("FS" ,0);
  PS = new Place("PS" ,0);
  short temp_ERTMSstateshort = 1;
  ERTMSstate = new ExtendedPlace<short>("ERTMSstate",temp_ERTMSstateshort);
  BaseStateVariableClass* InitialPlaces[4]={
    FSVC,  // 0
    FS,  // 1
    PS,  // 2
    ERTMSstate   // 3
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("ERTMSstates", 4, InitialPlaces, 
                        0, InitialROPlaces, 
                        5, InitialActionList, 5, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[15][2]={ 
    {0,0}, {1,0}, {3,0}, {1,1}, {0,1}, {3,1}, {0,2}, {2,2}, {3,2}, 
    {1,3}, {2,3}, {3,3}, {2,4}, {1,4}, {3,4}
  };
  for(int n=0;n<15;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[5][2]={ 
    {0,0}, {1,1}, {0,2}, {1,3}, {2,4}
  };
  for(int n=0;n<5;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<5;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void ERTMSstatesSAN::CustomInitialization() {

}
ERTMSstatesSAN::~ERTMSstatesSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void ERTMSstatesSAN::assignPlacesToActivitiesInst(){
}
void ERTMSstatesSAN::assignPlacesToActivitiesTimed(){
  fsvc2fs.FSVC = (Place*) LocalStateVariables[0];
  fsvc2fs.FS = (Place*) LocalStateVariables[1];
  fsvc2fs.ERTMSstate = (ExtendedPlace<short>*) LocalStateVariables[3];
  fs2fsvc.FS = (Place*) LocalStateVariables[1];
  fs2fsvc.FSVC = (Place*) LocalStateVariables[0];
  fs2fsvc.ERTMSstate = (ExtendedPlace<short>*) LocalStateVariables[3];
  fsvc2ps.FSVC = (Place*) LocalStateVariables[0];
  fsvc2ps.PS = (Place*) LocalStateVariables[2];
  fsvc2ps.ERTMSstate = (ExtendedPlace<short>*) LocalStateVariables[3];
  fs2ps.FS = (Place*) LocalStateVariables[1];
  fs2ps.PS = (Place*) LocalStateVariables[2];
  fs2ps.ERTMSstate = (ExtendedPlace<short>*) LocalStateVariables[3];
  repair.PS = (Place*) LocalStateVariables[2];
  repair.FS = (Place*) LocalStateVariables[1];
  repair.ERTMSstate = (ExtendedPlace<short>*) LocalStateVariables[3];
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================fsvc2fsActivity========================*/

ERTMSstatesSAN::fsvc2fsActivity::fsvc2fsActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("fsvc2fs",0,Exponential, RaceEnabled, 3,1, false);
}

ERTMSstatesSAN::fsvc2fsActivity::~fsvc2fsActivity(){
  delete[] TheDistributionParameters;
}

void ERTMSstatesSAN::fsvc2fsActivity::LinkVariables(){
  FSVC->Register(&FSVC_Mobius_Mark);
  FS->Register(&FS_Mobius_Mark);

}

bool ERTMSstatesSAN::fsvc2fsActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(FSVC_Mobius_Mark)) >=1));
  return NewEnabled;
}

double ERTMSstatesSAN::fsvc2fsActivity::Rate(){
  return (double) fsvc2fsRateH/3600.0;
  return 1.0;  // default rate if none is specified
}

double ERTMSstatesSAN::fsvc2fsActivity::Weight(){ 
  return 1;
}

bool ERTMSstatesSAN::fsvc2fsActivity::ReactivationPredicate(){ 
  return false;
}

bool ERTMSstatesSAN::fsvc2fsActivity::ReactivationFunction(){ 
  return false;
}

double ERTMSstatesSAN::fsvc2fsActivity::SampleDistribution(){
  return TheDistribution->Exponential( (double) fsvc2fsRateH/3600.0);
}

double* ERTMSstatesSAN::fsvc2fsActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int ERTMSstatesSAN::fsvc2fsActivity::Rank(){
  return 1;
}

BaseActionClass* ERTMSstatesSAN::fsvc2fsActivity::Fire(){
  (*(FSVC_Mobius_Mark))--;
  ERTMSstate->Mark()=2;
  (*(FS_Mobius_Mark))++;
  return this;
}

/*======================fs2fsvcActivity========================*/

ERTMSstatesSAN::fs2fsvcActivity::fs2fsvcActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("fs2fsvc",1,Exponential, RaceEnabled, 3,1, false);
}

ERTMSstatesSAN::fs2fsvcActivity::~fs2fsvcActivity(){
  delete[] TheDistributionParameters;
}

void ERTMSstatesSAN::fs2fsvcActivity::LinkVariables(){
  FS->Register(&FS_Mobius_Mark);
  FSVC->Register(&FSVC_Mobius_Mark);

}

bool ERTMSstatesSAN::fs2fsvcActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(FS_Mobius_Mark)) >=1));
  return NewEnabled;
}

double ERTMSstatesSAN::fs2fsvcActivity::Rate(){
  return (double) fs2fsvcRateH/3600.0;
  return 1.0;  // default rate if none is specified
}

double ERTMSstatesSAN::fs2fsvcActivity::Weight(){ 
  return 1;
}

bool ERTMSstatesSAN::fs2fsvcActivity::ReactivationPredicate(){ 
  return false;
}

bool ERTMSstatesSAN::fs2fsvcActivity::ReactivationFunction(){ 
  return false;
}

double ERTMSstatesSAN::fs2fsvcActivity::SampleDistribution(){
  return TheDistribution->Exponential( (double) fs2fsvcRateH/3600.0);
}

double* ERTMSstatesSAN::fs2fsvcActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int ERTMSstatesSAN::fs2fsvcActivity::Rank(){
  return 1;
}

BaseActionClass* ERTMSstatesSAN::fs2fsvcActivity::Fire(){
  (*(FS_Mobius_Mark))--;
  ERTMSstate->Mark()=1;
  (*(FSVC_Mobius_Mark))++;
  return this;
}

/*======================fsvc2psActivity========================*/

ERTMSstatesSAN::fsvc2psActivity::fsvc2psActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("fsvc2ps",2,Exponential, RaceEnabled, 3,1, false);
}

ERTMSstatesSAN::fsvc2psActivity::~fsvc2psActivity(){
  delete[] TheDistributionParameters;
}

void ERTMSstatesSAN::fsvc2psActivity::LinkVariables(){
  FSVC->Register(&FSVC_Mobius_Mark);
  PS->Register(&PS_Mobius_Mark);

}

bool ERTMSstatesSAN::fsvc2psActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(FSVC_Mobius_Mark)) >=1));
  return NewEnabled;
}

double ERTMSstatesSAN::fsvc2psActivity::Rate(){
  return (double) fs2psRateH/3600.0;
  return 1.0;  // default rate if none is specified
}

double ERTMSstatesSAN::fsvc2psActivity::Weight(){ 
  return 1;
}

bool ERTMSstatesSAN::fsvc2psActivity::ReactivationPredicate(){ 
  return false;
}

bool ERTMSstatesSAN::fsvc2psActivity::ReactivationFunction(){ 
  return false;
}

double ERTMSstatesSAN::fsvc2psActivity::SampleDistribution(){
  return TheDistribution->Exponential( (double) fs2psRateH/3600.0);
}

double* ERTMSstatesSAN::fsvc2psActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int ERTMSstatesSAN::fsvc2psActivity::Rank(){
  return 1;
}

BaseActionClass* ERTMSstatesSAN::fsvc2psActivity::Fire(){
  (*(FSVC_Mobius_Mark))--;
  ERTMSstate->Mark()=3;
  (*(PS_Mobius_Mark))++;
  return this;
}

/*======================fs2psActivity========================*/

ERTMSstatesSAN::fs2psActivity::fs2psActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("fs2ps",3,Exponential, RaceEnabled, 3,1, false);
}

ERTMSstatesSAN::fs2psActivity::~fs2psActivity(){
  delete[] TheDistributionParameters;
}

void ERTMSstatesSAN::fs2psActivity::LinkVariables(){
  FS->Register(&FS_Mobius_Mark);
  PS->Register(&PS_Mobius_Mark);

}

bool ERTMSstatesSAN::fs2psActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(FS_Mobius_Mark)) >=1));
  return NewEnabled;
}

double ERTMSstatesSAN::fs2psActivity::Rate(){
  return fs2psRateH/3600.0;
  return 1.0;  // default rate if none is specified
}

double ERTMSstatesSAN::fs2psActivity::Weight(){ 
  return 1;
}

bool ERTMSstatesSAN::fs2psActivity::ReactivationPredicate(){ 
  return false;
}

bool ERTMSstatesSAN::fs2psActivity::ReactivationFunction(){ 
  return false;
}

double ERTMSstatesSAN::fs2psActivity::SampleDistribution(){
  return TheDistribution->Exponential( fs2psRateH/3600.0);
}

double* ERTMSstatesSAN::fs2psActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int ERTMSstatesSAN::fs2psActivity::Rank(){
  return 1;
}

BaseActionClass* ERTMSstatesSAN::fs2psActivity::Fire(){
  (*(FS_Mobius_Mark))--;
  ERTMSstate->Mark()=3;
  (*(PS_Mobius_Mark))++;
  return this;
}

/*======================repairActivity========================*/

ERTMSstatesSAN::repairActivity::repairActivity(){
  TheDistributionParameters = new double[2];
  ActivityInitialize("repair",4,Normal, RaceEnabled, 3,1, false);
}

ERTMSstatesSAN::repairActivity::~repairActivity(){
  delete[] TheDistributionParameters;
}

void ERTMSstatesSAN::repairActivity::LinkVariables(){
  PS->Register(&PS_Mobius_Mark);
  FS->Register(&FS_Mobius_Mark);

}

bool ERTMSstatesSAN::repairActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(PS_Mobius_Mark)) >=1));
  return NewEnabled;
}

double ERTMSstatesSAN::repairActivity::NormalParamMean(){
  return repairRateH*3600.0;
  return 1.0;  // default rate if none is specified
}

double ERTMSstatesSAN::repairActivity::NormalParamVariance(){
  return 100;
  return 1.0;  // default rate if none is specified
}

double ERTMSstatesSAN::repairActivity::Weight(){ 
  return 1;
}

bool ERTMSstatesSAN::repairActivity::ReactivationPredicate(){ 
  return false;
}

bool ERTMSstatesSAN::repairActivity::ReactivationFunction(){ 
  return false;
}

double ERTMSstatesSAN::repairActivity::SampleDistribution(){
  return TheDistribution->Normal( repairRateH*3600.0,  100);
}

double* ERTMSstatesSAN::repairActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = NormalParamMean();
  TheDistributionParameters[1] = NormalParamVariance();
  return TheDistributionParameters;
}

int ERTMSstatesSAN::repairActivity::Rank(){
  return 1;
}

BaseActionClass* ERTMSstatesSAN::repairActivity::Fire(){
  (*(PS_Mobius_Mark))--;
  ERTMSstate->Mark()=2;
  (*(FS_Mobius_Mark))++;
  return this;
}

