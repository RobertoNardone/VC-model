#ifndef ERTMSstatesSAN_H_
#define ERTMSstatesSAN_H_

#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern Short numOfTrains;
extern Double fsvc2fsRateH;
extern Double fs2fsvcRateH;
extern Double fs2psRateH;
extern Double repairRateH;
extern UserDistributions* TheDistribution;

void MemoryError();

#ifndef _TrainArray_header_
#define _TrainArray_header_

typedef short TrainArray_state;
class TrainArray: public ArrayStateVariable<ExtendedPlace<short> > {
  public:
  TrainArray(char* name, char* fullname):
    ArrayStateVariable<ExtendedPlace<short> >(name, fullname, ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, fqname));
    }
  }

  TrainArray(char* name):
    ArrayStateVariable<ExtendedPlace<short> >(name, "", ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, name));
    }
  }

  TrainArray(char* name, char* fullname, short & initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, fullname, ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, fqname, initialValue));
    }
  }

  TrainArray(char* name, short & initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, "", ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, name, initialValue));
    }
  }

  TrainArray(char* name, char* fullname, short * initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, fullname, ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, fqname, initialValue[i]));
    }
  }

  TrainArray(char* name, short * initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, "", ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, name, initialValue[i]));
    }
  }
  ~TrainArray() {
    for (fieldIterator i=fields.begin();i!=fields.end();++i)
      delete (*i);
  }
};
#endif

/*********************************************************************
               ERTMSstatesSAN Submodel Definition                   
*********************************************************************/

class ERTMSstatesSAN:public SANModel{
public:

class fsvc2fsActivity:public Activity {
public:

  Place* FSVC;
  short* FSVC_Mobius_Mark;
  Place* FS;
  short* FS_Mobius_Mark;
  ExtendedPlace<short>* ERTMSstate;

  double* TheDistributionParameters;
  fsvc2fsActivity();
  ~fsvc2fsActivity();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // fsvc2fsActivityActivity

class fs2fsvcActivity:public Activity {
public:

  Place* FS;
  short* FS_Mobius_Mark;
  Place* FSVC;
  short* FSVC_Mobius_Mark;
  ExtendedPlace<short>* ERTMSstate;

  double* TheDistributionParameters;
  fs2fsvcActivity();
  ~fs2fsvcActivity();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // fs2fsvcActivityActivity

class fsvc2psActivity:public Activity {
public:

  Place* FSVC;
  short* FSVC_Mobius_Mark;
  Place* PS;
  short* PS_Mobius_Mark;
  ExtendedPlace<short>* ERTMSstate;

  double* TheDistributionParameters;
  fsvc2psActivity();
  ~fsvc2psActivity();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // fsvc2psActivityActivity

class fs2psActivity:public Activity {
public:

  Place* FS;
  short* FS_Mobius_Mark;
  Place* PS;
  short* PS_Mobius_Mark;
  ExtendedPlace<short>* ERTMSstate;

  double* TheDistributionParameters;
  fs2psActivity();
  ~fs2psActivity();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // fs2psActivityActivity

class repairActivity:public Activity {
public:

  Place* PS;
  short* PS_Mobius_Mark;
  Place* FS;
  short* FS_Mobius_Mark;
  ExtendedPlace<short>* ERTMSstate;

  double* TheDistributionParameters;
  repairActivity();
  ~repairActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double NormalParamMean();
  double NormalParamVariance();
}; // repairActivityActivity

  //List of user-specified place names
  Place* FSVC;
  Place* FS;
  Place* PS;
  ExtendedPlace<short>* ERTMSstate;

  // Create instances of all actvities
  fsvc2fsActivity fsvc2fs;
  fs2fsvcActivity fs2fsvc;
  fsvc2psActivity fsvc2ps;
  fs2psActivity fs2ps;
  repairActivity repair;
  //Create instances of all groups 
  EmptyGroup ImmediateGroup;

  ERTMSstatesSAN();
  ~ERTMSstatesSAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end ERTMSstatesSAN

#endif // ERTMSstatesSAN_H_
