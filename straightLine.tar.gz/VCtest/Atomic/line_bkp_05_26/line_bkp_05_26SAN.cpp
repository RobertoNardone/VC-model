

// This C++ file was created by SanEditor

#include "Atomic/line_bkp_05_26/line_bkp_05_26SAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         line_bkp_05_26SAN Constructor             
******************************************************************/


line_bkp_05_26SAN::line_bkp_05_26SAN(){


  Activity* InitialActionList[47]={
    &counting, //0
    &step205, //1
    &step105, //2
    &step204, //3
    &step104, //4
    &step203, //5
    &step103, //6
    &step202, //7
    &step102, //8
    &step201, //9
    &step101, //10
    &step100, //11
    &arrivalFrom100, //12
    &step200, //13
    &arrivalFrom200, //14
    &step106, //15
    &step206, //16
    &step207, //17
    &step107, //18
    &step208, //19
    &step108, //20
    &step209, //21
    &step109, //22
    &step210, //23
    &step110, //24
    &step211, //25
    &step111, //26
    &step117, //27
    &step216, //28
    &step116, //29
    &step217, //30
    &step215, //31
    &step115, //32
    &step214, //33
    &step114, //34
    &step213, //35
    &step113, //36
    &step112, //37
    &step212, //38
    &step220, //39
    &step219, //40
    &step218, //41
    &step122, //42
    &step121, //43
    &step120, //44
    &step119, //45
    &step118  // 46
  };

  BaseGroupClass* InitialGroupList[47]={
    (BaseGroupClass*) &(step205), 
    (BaseGroupClass*) &(step105), 
    (BaseGroupClass*) &(step204), 
    (BaseGroupClass*) &(step104), 
    (BaseGroupClass*) &(step203), 
    (BaseGroupClass*) &(step103), 
    (BaseGroupClass*) &(step202), 
    (BaseGroupClass*) &(step102), 
    (BaseGroupClass*) &(step201), 
    (BaseGroupClass*) &(step101), 
    (BaseGroupClass*) &(step100), 
    (BaseGroupClass*) &(arrivalFrom100), 
    (BaseGroupClass*) &(step200), 
    (BaseGroupClass*) &(arrivalFrom200), 
    (BaseGroupClass*) &(step106), 
    (BaseGroupClass*) &(step206), 
    (BaseGroupClass*) &(step207), 
    (BaseGroupClass*) &(step107), 
    (BaseGroupClass*) &(step208), 
    (BaseGroupClass*) &(step108), 
    (BaseGroupClass*) &(step209), 
    (BaseGroupClass*) &(step109), 
    (BaseGroupClass*) &(step210), 
    (BaseGroupClass*) &(step110), 
    (BaseGroupClass*) &(step211), 
    (BaseGroupClass*) &(step111), 
    (BaseGroupClass*) &(step117), 
    (BaseGroupClass*) &(step216), 
    (BaseGroupClass*) &(step116), 
    (BaseGroupClass*) &(step217), 
    (BaseGroupClass*) &(step215), 
    (BaseGroupClass*) &(step115), 
    (BaseGroupClass*) &(step214), 
    (BaseGroupClass*) &(step114), 
    (BaseGroupClass*) &(step213), 
    (BaseGroupClass*) &(step113), 
    (BaseGroupClass*) &(step112), 
    (BaseGroupClass*) &(step212), 
    (BaseGroupClass*) &(step220), 
    (BaseGroupClass*) &(step219), 
    (BaseGroupClass*) &(step218), 
    (BaseGroupClass*) &(step122), 
    (BaseGroupClass*) &(step121), 
    (BaseGroupClass*) &(step120), 
    (BaseGroupClass*) &(step119), 
    (BaseGroupClass*) &(step118), 
    (BaseGroupClass*) &(counting)
  };

  short temp_sec206short = 0;
  sec206 = new ExtendedPlace<short>("sec206",temp_sec206short);
  short temp_sec106short = 0;
  sec106 = new ExtendedPlace<short>("sec106",temp_sec106short);
  short temp_sec205short = 0;
  sec205 = new ExtendedPlace<short>("sec205",temp_sec205short);
  short temp_sec105short = 0;
  sec105 = new ExtendedPlace<short>("sec105",temp_sec105short);
  short temp_sec204short = 0;
  sec204 = new ExtendedPlace<short>("sec204",temp_sec204short);
  short temp_sec104short = 0;
  sec104 = new ExtendedPlace<short>("sec104",temp_sec104short);
  short temp_sec203short = 0;
  sec203 = new ExtendedPlace<short>("sec203",temp_sec203short);
  short temp_sec103short = 0;
  sec103 = new ExtendedPlace<short>("sec103",temp_sec103short);
  short temp_sec202short = 0;
  sec202 = new ExtendedPlace<short>("sec202",temp_sec202short);
  short temp_sec102short = 0;
  sec102 = new ExtendedPlace<short>("sec102",temp_sec102short);
  short temp_sec201short = 0;
  sec201 = new ExtendedPlace<short>("sec201",temp_sec201short);
  short temp_sec101short = 0;
  sec101 = new ExtendedPlace<short>("sec101",temp_sec101short);
  short temp_trStatesTrainArrayvalue = 0;
  trStates = new TrainArray("trStates",temp_trStatesTrainArrayvalue);
  short temp_sec100short = 0;
  sec100 = new ExtendedPlace<short>("sec100",temp_sec100short);
  short temp_sec200short = 0;
  sec200 = new ExtendedPlace<short>("sec200",temp_sec200short);
  short temp_last_id1short = 0;
  last_id1 = new ExtendedPlace<short>("last_id1",temp_last_id1short);
  short temp_last_id2short = 10;
  last_id2 = new ExtendedPlace<short>("last_id2",temp_last_id2short);
  short temp_sec207short = 0;
  sec207 = new ExtendedPlace<short>("sec207",temp_sec207short);
  short temp_sec107short = 0;
  sec107 = new ExtendedPlace<short>("sec107",temp_sec107short);
  short temp_sec208short = 0;
  sec208 = new ExtendedPlace<short>("sec208",temp_sec208short);
  short temp_sec108short = 0;
  sec108 = new ExtendedPlace<short>("sec108",temp_sec108short);
  short temp_sec209short = 0;
  sec209 = new ExtendedPlace<short>("sec209",temp_sec209short);
  short temp_sec109short = 0;
  sec109 = new ExtendedPlace<short>("sec109",temp_sec109short);
  short temp_sec210short = 0;
  sec210 = new ExtendedPlace<short>("sec210",temp_sec210short);
  short temp_sec110short = 0;
  sec110 = new ExtendedPlace<short>("sec110",temp_sec110short);
  short temp_sec211short = 0;
  sec211 = new ExtendedPlace<short>("sec211",temp_sec211short);
  short temp_sec111short = 0;
  sec111 = new ExtendedPlace<short>("sec111",temp_sec111short);
  short temp_sec212short = 0;
  sec212 = new ExtendedPlace<short>("sec212",temp_sec212short);
  short temp_sec112short = 0;
  sec112 = new ExtendedPlace<short>("sec112",temp_sec112short);
  short temp_sec118short = 0;
  sec118 = new ExtendedPlace<short>("sec118",temp_sec118short);
  short temp_sec117short = 0;
  sec117 = new ExtendedPlace<short>("sec117",temp_sec117short);
  short temp_sec217short = 0;
  sec217 = new ExtendedPlace<short>("sec217",temp_sec217short);
  short temp_sec218short = 0;
  sec218 = new ExtendedPlace<short>("sec218",temp_sec218short);
  short temp_sec216short = 0;
  sec216 = new ExtendedPlace<short>("sec216",temp_sec216short);
  short temp_sec116short = 0;
  sec116 = new ExtendedPlace<short>("sec116",temp_sec116short);
  short temp_sec215short = 0;
  sec215 = new ExtendedPlace<short>("sec215",temp_sec215short);
  short temp_sec115short = 0;
  sec115 = new ExtendedPlace<short>("sec115",temp_sec115short);
  short temp_sec214short = 0;
  sec214 = new ExtendedPlace<short>("sec214",temp_sec214short);
  short temp_sec114short = 0;
  sec114 = new ExtendedPlace<short>("sec114",temp_sec114short);
  short temp_sec213short = 0;
  sec213 = new ExtendedPlace<short>("sec213",temp_sec213short);
  short temp_sec113short = 0;
  sec113 = new ExtendedPlace<short>("sec113",temp_sec113short);
  short temp_sec220short = 0;
  sec220 = new ExtendedPlace<short>("sec220",temp_sec220short);
  short temp_sec219short = 0;
  sec219 = new ExtendedPlace<short>("sec219",temp_sec219short);
  short temp_sec123short = 0;
  sec123 = new ExtendedPlace<short>("sec123",temp_sec123short);
  short temp_sec122short = 0;
  sec122 = new ExtendedPlace<short>("sec122",temp_sec122short);
  short temp_sec121short = 0;
  sec121 = new ExtendedPlace<short>("sec121",temp_sec121short);
  short temp_sec120short = 0;
  sec120 = new ExtendedPlace<short>("sec120",temp_sec120short);
  short temp_sec119short = 0;
  sec119 = new ExtendedPlace<short>("sec119",temp_sec119short);
  short temp_counter_LastIdshort = 0;
  counter_LastId = new ExtendedPlace<short>("counter_LastId",temp_counter_LastIdshort);
  short temp_countedshort = 0;
  counted = new ExtendedPlace<short>("counted",temp_countedshort);
  BaseStateVariableClass* InitialPlaces[50]={
    sec206,  // 0
    sec106,  // 1
    sec205,  // 2
    sec105,  // 3
    sec204,  // 4
    sec104,  // 5
    sec203,  // 6
    sec103,  // 7
    sec202,  // 8
    sec102,  // 9
    sec201,  // 10
    sec101,  // 11
    trStates,  // 12
    sec100,  // 13
    sec200,  // 14
    last_id1,  // 15
    last_id2,  // 16
    sec207,  // 17
    sec107,  // 18
    sec208,  // 19
    sec108,  // 20
    sec209,  // 21
    sec109,  // 22
    sec210,  // 23
    sec110,  // 24
    sec211,  // 25
    sec111,  // 26
    sec212,  // 27
    sec112,  // 28
    sec118,  // 29
    sec117,  // 30
    sec217,  // 31
    sec218,  // 32
    sec216,  // 33
    sec116,  // 34
    sec215,  // 35
    sec115,  // 36
    sec214,  // 37
    sec114,  // 38
    sec213,  // 39
    sec113,  // 40
    sec220,  // 41
    sec219,  // 42
    sec123,  // 43
    sec122,  // 44
    sec121,  // 45
    sec120,  // 46
    sec119,  // 47
    counter_LastId,  // 48
    counted   // 49
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("line_bkp_05_26", 50, InitialPlaces, 
                        0, InitialROPlaces, 
                        47, InitialActionList, 47, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[133][2]={ 
    {43,0}, {48,0}, {49,0}, {0,1}, {2,1}, {10,1}, {1,2}, {3,2}, 
    {11,2}, {2,3}, {4,3}, {14,3}, {3,4}, {5,4}, {13,4}, {4,5}, 
    {6,5}, {5,6}, {7,6}, {6,7}, {8,7}, {7,8}, {9,8}, {8,9}, {10,9}, 
    {9,10}, {11,10}, {11,11}, {13,11}, {13,12}, {15,12}, {10,13}, 
    {14,13}, {14,14}, {16,14}, {18,15}, {1,15}, {9,15}, {17,16}, 
    {0,16}, {8,16}, {19,17}, {17,17}, {6,17}, {20,18}, {18,18}, 
    {7,18}, {21,19}, {19,19}, {4,19}, {22,20}, {20,20}, {5,20}, 
    {23,21}, {21,21}, {2,21}, {24,22}, {22,22}, {3,22}, {25,23}, 
    {23,23}, {0,23}, {26,24}, {24,24}, {1,24}, {27,25}, {25,25}, 
    {17,25}, {28,26}, {24,26}, {18,26}, {29,27}, {30,27}, {40,27}, 
    {31,28}, {33,28}, {27,28}, {30,29}, {34,29}, {28,29}, {32,30}, 
    {31,30}, {39,30}, {33,31}, {35,31}, {25,31}, {34,32}, {36,32}, 
    {26,32}, {35,33}, {37,33}, {23,33}, {36,34}, {38,34}, {24,34}, 
    {37,35}, {39,35}, {21,35}, {38,36}, {40,36}, {22,36}, {40,37}, 
    {28,37}, {20,37}, {39,38}, {27,38}, {19,38}, {45,39}, {41,39}, 
    {33,39}, {41,40}, {42,40}, {35,40}, {42,41}, {32,41}, {37,41}, 
    {43,42}, {44,42}, {32,42}, {29,42}, {44,43}, {45,43}, {31,43}, 
    {30,43}, {45,44}, {46,44}, {34,44}, {46,45}, {47,45}, {36,45}, 
    {47,46}, {29,46}, {38,46}
  };
  for(int n=0;n<133;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[88][2]={ 
    {43,0}, {2,1}, {0,1}, {3,2}, {1,2}, {4,3}, {2,3}, {5,4}, 
    {3,4}, {6,5}, {4,5}, {7,6}, {5,6}, {8,7}, {6,7}, {9,8}, {7,8}, 
    {10,9}, {8,9}, {11,10}, {9,10}, {13,11}, {11,11}, {14,13}, 
    {10,13}, {1,15}, {18,15}, {0,16}, {17,16}, {17,17}, {19,17}, 
    {18,18}, {20,18}, {19,19}, {21,19}, {20,20}, {22,20}, {21,21}, 
    {23,21}, {22,22}, {24,22}, {23,23}, {25,23}, {24,24}, {26,24}, 
    {25,25}, {27,25}, {26,26}, {28,26}, {30,27}, {29,27}, {33,28}, 
    {31,28}, {34,29}, {30,29}, {31,30}, {32,30}, {35,31}, {33,31}, 
    {36,32}, {34,32}, {37,33}, {35,33}, {38,34}, {36,34}, {39,35}, 
    {37,35}, {40,36}, {38,36}, {28,37}, {40,37}, {27,38}, {39,38}, 
    {41,39}, {45,39}, {42,40}, {41,40}, {32,41}, {42,41}, {44,42}, 
    {45,43}, {44,43}, {46,44}, {45,44}, {47,45}, {46,45}, {29,46}, 
    {47,46}
  };
  for(int n=0;n<88;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<47;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void line_bkp_05_26SAN::CustomInitialization() {

}
line_bkp_05_26SAN::~line_bkp_05_26SAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void line_bkp_05_26SAN::assignPlacesToActivitiesInst(){
  counting.sec123 = (ExtendedPlace<short>*) LocalStateVariables[43];
  counting.counter_LastId = (ExtendedPlace<short>*) LocalStateVariables[48];
  counting.counted = (ExtendedPlace<short>*) LocalStateVariables[49];
}
void line_bkp_05_26SAN::assignPlacesToActivitiesTimed(){
  step205.sec205 = (ExtendedPlace<short>*) LocalStateVariables[2];
  step205.sec206 = (ExtendedPlace<short>*) LocalStateVariables[0];
  step205.sec201 = (ExtendedPlace<short>*) LocalStateVariables[10];
  step105.sec105 = (ExtendedPlace<short>*) LocalStateVariables[3];
  step105.sec106 = (ExtendedPlace<short>*) LocalStateVariables[1];
  step105.sec101 = (ExtendedPlace<short>*) LocalStateVariables[11];
  step204.sec204 = (ExtendedPlace<short>*) LocalStateVariables[4];
  step204.sec205 = (ExtendedPlace<short>*) LocalStateVariables[2];
  step204.sec200 = (ExtendedPlace<short>*) LocalStateVariables[14];
  step104.sec104 = (ExtendedPlace<short>*) LocalStateVariables[5];
  step104.sec105 = (ExtendedPlace<short>*) LocalStateVariables[3];
  step104.sec100 = (ExtendedPlace<short>*) LocalStateVariables[13];
  step203.sec203 = (ExtendedPlace<short>*) LocalStateVariables[6];
  step203.sec204 = (ExtendedPlace<short>*) LocalStateVariables[4];
  step103.sec103 = (ExtendedPlace<short>*) LocalStateVariables[7];
  step103.sec104 = (ExtendedPlace<short>*) LocalStateVariables[5];
  step202.sec202 = (ExtendedPlace<short>*) LocalStateVariables[8];
  step202.sec203 = (ExtendedPlace<short>*) LocalStateVariables[6];
  step102.sec102 = (ExtendedPlace<short>*) LocalStateVariables[9];
  step102.sec103 = (ExtendedPlace<short>*) LocalStateVariables[7];
  step201.sec201 = (ExtendedPlace<short>*) LocalStateVariables[10];
  step201.sec202 = (ExtendedPlace<short>*) LocalStateVariables[8];
  step101.sec101 = (ExtendedPlace<short>*) LocalStateVariables[11];
  step101.sec102 = (ExtendedPlace<short>*) LocalStateVariables[9];
  step100.sec100 = (ExtendedPlace<short>*) LocalStateVariables[13];
  step100.sec101 = (ExtendedPlace<short>*) LocalStateVariables[11];
  arrivalFrom100.sec100 = (ExtendedPlace<short>*) LocalStateVariables[13];
  arrivalFrom100.last_id1 = (ExtendedPlace<short>*) LocalStateVariables[15];
  step200.sec200 = (ExtendedPlace<short>*) LocalStateVariables[14];
  step200.sec201 = (ExtendedPlace<short>*) LocalStateVariables[10];
  arrivalFrom200.sec200 = (ExtendedPlace<short>*) LocalStateVariables[14];
  arrivalFrom200.last_id2 = (ExtendedPlace<short>*) LocalStateVariables[16];
  step106.sec106 = (ExtendedPlace<short>*) LocalStateVariables[1];
  step106.sec107 = (ExtendedPlace<short>*) LocalStateVariables[18];
  step106.sec102 = (ExtendedPlace<short>*) LocalStateVariables[9];
  step206.sec206 = (ExtendedPlace<short>*) LocalStateVariables[0];
  step206.sec207 = (ExtendedPlace<short>*) LocalStateVariables[17];
  step206.sec202 = (ExtendedPlace<short>*) LocalStateVariables[8];
  step207.sec207 = (ExtendedPlace<short>*) LocalStateVariables[17];
  step207.sec208 = (ExtendedPlace<short>*) LocalStateVariables[19];
  step207.sec203 = (ExtendedPlace<short>*) LocalStateVariables[6];
  step107.sec107 = (ExtendedPlace<short>*) LocalStateVariables[18];
  step107.sec108 = (ExtendedPlace<short>*) LocalStateVariables[20];
  step107.sec103 = (ExtendedPlace<short>*) LocalStateVariables[7];
  step208.sec208 = (ExtendedPlace<short>*) LocalStateVariables[19];
  step208.sec209 = (ExtendedPlace<short>*) LocalStateVariables[21];
  step208.sec204 = (ExtendedPlace<short>*) LocalStateVariables[4];
  step108.sec108 = (ExtendedPlace<short>*) LocalStateVariables[20];
  step108.sec109 = (ExtendedPlace<short>*) LocalStateVariables[22];
  step108.sec104 = (ExtendedPlace<short>*) LocalStateVariables[5];
  step209.sec209 = (ExtendedPlace<short>*) LocalStateVariables[21];
  step209.sec210 = (ExtendedPlace<short>*) LocalStateVariables[23];
  step209.sec205 = (ExtendedPlace<short>*) LocalStateVariables[2];
  step109.sec109 = (ExtendedPlace<short>*) LocalStateVariables[22];
  step109.sec110 = (ExtendedPlace<short>*) LocalStateVariables[24];
  step109.sec105 = (ExtendedPlace<short>*) LocalStateVariables[3];
  step210.sec210 = (ExtendedPlace<short>*) LocalStateVariables[23];
  step210.sec211 = (ExtendedPlace<short>*) LocalStateVariables[25];
  step210.sec206 = (ExtendedPlace<short>*) LocalStateVariables[0];
  step110.sec110 = (ExtendedPlace<short>*) LocalStateVariables[24];
  step110.sec111 = (ExtendedPlace<short>*) LocalStateVariables[26];
  step110.sec106 = (ExtendedPlace<short>*) LocalStateVariables[1];
  step211.sec211 = (ExtendedPlace<short>*) LocalStateVariables[25];
  step211.sec212 = (ExtendedPlace<short>*) LocalStateVariables[27];
  step211.sec207 = (ExtendedPlace<short>*) LocalStateVariables[17];
  step111.sec111 = (ExtendedPlace<short>*) LocalStateVariables[26];
  step111.sec112 = (ExtendedPlace<short>*) LocalStateVariables[28];
  step111.sec110 = (ExtendedPlace<short>*) LocalStateVariables[24];
  step111.sec107 = (ExtendedPlace<short>*) LocalStateVariables[18];
  step117.sec117 = (ExtendedPlace<short>*) LocalStateVariables[30];
  step117.sec118 = (ExtendedPlace<short>*) LocalStateVariables[29];
  step117.sec113 = (ExtendedPlace<short>*) LocalStateVariables[40];
  step216.sec216 = (ExtendedPlace<short>*) LocalStateVariables[33];
  step216.sec217 = (ExtendedPlace<short>*) LocalStateVariables[31];
  step216.sec212 = (ExtendedPlace<short>*) LocalStateVariables[27];
  step116.sec116 = (ExtendedPlace<short>*) LocalStateVariables[34];
  step116.sec117 = (ExtendedPlace<short>*) LocalStateVariables[30];
  step116.sec112 = (ExtendedPlace<short>*) LocalStateVariables[28];
  step217.sec217 = (ExtendedPlace<short>*) LocalStateVariables[31];
  step217.sec218 = (ExtendedPlace<short>*) LocalStateVariables[32];
  step217.sec213 = (ExtendedPlace<short>*) LocalStateVariables[39];
  step215.sec215 = (ExtendedPlace<short>*) LocalStateVariables[35];
  step215.sec216 = (ExtendedPlace<short>*) LocalStateVariables[33];
  step215.sec211 = (ExtendedPlace<short>*) LocalStateVariables[25];
  step115.sec115 = (ExtendedPlace<short>*) LocalStateVariables[36];
  step115.sec116 = (ExtendedPlace<short>*) LocalStateVariables[34];
  step115.sec111 = (ExtendedPlace<short>*) LocalStateVariables[26];
  step214.sec214 = (ExtendedPlace<short>*) LocalStateVariables[37];
  step214.sec215 = (ExtendedPlace<short>*) LocalStateVariables[35];
  step214.sec210 = (ExtendedPlace<short>*) LocalStateVariables[23];
  step114.sec114 = (ExtendedPlace<short>*) LocalStateVariables[38];
  step114.sec115 = (ExtendedPlace<short>*) LocalStateVariables[36];
  step114.sec110 = (ExtendedPlace<short>*) LocalStateVariables[24];
  step213.sec213 = (ExtendedPlace<short>*) LocalStateVariables[39];
  step213.sec214 = (ExtendedPlace<short>*) LocalStateVariables[37];
  step213.sec209 = (ExtendedPlace<short>*) LocalStateVariables[21];
  step113.sec113 = (ExtendedPlace<short>*) LocalStateVariables[40];
  step113.sec114 = (ExtendedPlace<short>*) LocalStateVariables[38];
  step113.sec109 = (ExtendedPlace<short>*) LocalStateVariables[22];
  step112.sec112 = (ExtendedPlace<short>*) LocalStateVariables[28];
  step112.sec113 = (ExtendedPlace<short>*) LocalStateVariables[40];
  step112.sec108 = (ExtendedPlace<short>*) LocalStateVariables[20];
  step212.sec212 = (ExtendedPlace<short>*) LocalStateVariables[27];
  step212.sec213 = (ExtendedPlace<short>*) LocalStateVariables[39];
  step212.sec208 = (ExtendedPlace<short>*) LocalStateVariables[19];
  step220.sec220 = (ExtendedPlace<short>*) LocalStateVariables[41];
  step220.sec121 = (ExtendedPlace<short>*) LocalStateVariables[45];
  step220.sec216 = (ExtendedPlace<short>*) LocalStateVariables[33];
  step219.sec219 = (ExtendedPlace<short>*) LocalStateVariables[42];
  step219.sec220 = (ExtendedPlace<short>*) LocalStateVariables[41];
  step219.sec215 = (ExtendedPlace<short>*) LocalStateVariables[35];
  step218.sec218 = (ExtendedPlace<short>*) LocalStateVariables[32];
  step218.sec219 = (ExtendedPlace<short>*) LocalStateVariables[42];
  step218.sec214 = (ExtendedPlace<short>*) LocalStateVariables[37];
  step122.sec122 = (ExtendedPlace<short>*) LocalStateVariables[44];
  step122.sec123 = (ExtendedPlace<short>*) LocalStateVariables[43];
  step122.sec218 = (ExtendedPlace<short>*) LocalStateVariables[32];
  step122.sec118 = (ExtendedPlace<short>*) LocalStateVariables[29];
  step121.sec121 = (ExtendedPlace<short>*) LocalStateVariables[45];
  step121.sec122 = (ExtendedPlace<short>*) LocalStateVariables[44];
  step121.sec217 = (ExtendedPlace<short>*) LocalStateVariables[31];
  step121.sec117 = (ExtendedPlace<short>*) LocalStateVariables[30];
  step120.sec120 = (ExtendedPlace<short>*) LocalStateVariables[46];
  step120.sec121 = (ExtendedPlace<short>*) LocalStateVariables[45];
  step120.sec116 = (ExtendedPlace<short>*) LocalStateVariables[34];
  step119.sec119 = (ExtendedPlace<short>*) LocalStateVariables[47];
  step119.sec120 = (ExtendedPlace<short>*) LocalStateVariables[46];
  step119.sec115 = (ExtendedPlace<short>*) LocalStateVariables[36];
  step118.sec118 = (ExtendedPlace<short>*) LocalStateVariables[29];
  step118.sec119 = (ExtendedPlace<short>*) LocalStateVariables[47];
  step118.sec114 = (ExtendedPlace<short>*) LocalStateVariables[38];
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================countingActivity========================*/


line_bkp_05_26SAN::countingActivity::countingActivity(){
  ActivityInitialize("counting",46,Instantaneous , RaceEnabled, 3,1, false);
}

void line_bkp_05_26SAN::countingActivity::LinkVariables(){



}

bool line_bkp_05_26SAN::countingActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec123->Mark()>0));
  return NewEnabled;
}

double line_bkp_05_26SAN::countingActivity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::countingActivity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::countingActivity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::countingActivity::SampleDistribution(){
  return 0;
}

double* line_bkp_05_26SAN::countingActivity::ReturnDistributionParameters(){
    return NULL;
}

int line_bkp_05_26SAN::countingActivity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::countingActivity::Fire(){
  if(sec123->Mark()!=counter_LastId->Mark()) {
counted->Mark()++;
counter_LastId->Mark()=sec123->Mark();
}
sec123->Mark()=0;
  return this;
}

/*======================step205Activity========================*/

line_bkp_05_26SAN::step205Activity::step205Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step205",0,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step205Activity::~step205Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step205Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step205Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec205->Mark()>0 && sec206->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step205Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step205Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step205Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step205Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step205Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step205Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step205Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step205Activity::Fire(){
  ;
  sec206->Mark()=sec205->Mark();

sec201->Mark()=0;
  return this;
}

/*======================step105Activity========================*/

line_bkp_05_26SAN::step105Activity::step105Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step105",1,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step105Activity::~step105Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step105Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step105Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec105->Mark()>0 && sec106->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step105Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step105Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step105Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step105Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step105Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step105Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step105Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step105Activity::Fire(){
  ;
  sec106->Mark()=sec105->Mark();

sec101->Mark()=0;
  return this;
}

/*======================step204Activity========================*/

line_bkp_05_26SAN::step204Activity::step204Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step204",2,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step204Activity::~step204Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step204Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step204Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec204->Mark()>0 && sec205->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step204Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step204Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step204Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step204Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step204Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step204Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step204Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step204Activity::Fire(){
  ;
  sec205->Mark()=sec204->Mark();

sec200->Mark()=0;
  return this;
}

/*======================step104Activity========================*/

line_bkp_05_26SAN::step104Activity::step104Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step104",3,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step104Activity::~step104Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step104Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step104Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec104->Mark()>0 && sec105->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step104Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step104Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step104Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step104Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step104Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step104Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step104Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step104Activity::Fire(){
  ;
  sec105->Mark()=sec104->Mark();

sec100->Mark()=0;
  return this;
}

/*======================step203Activity========================*/

line_bkp_05_26SAN::step203Activity::step203Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step203",4,Deterministic, RaceEnabled, 2,2, false);
}

line_bkp_05_26SAN::step203Activity::~step203Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step203Activity::LinkVariables(){


}

bool line_bkp_05_26SAN::step203Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec203->Mark()>0 && sec204->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step203Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step203Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step203Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step203Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step203Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step203Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step203Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step203Activity::Fire(){
  ;
  sec204->Mark()=sec203->Mark();
  return this;
}

/*======================step103Activity========================*/

line_bkp_05_26SAN::step103Activity::step103Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step103",5,Deterministic, RaceEnabled, 2,2, false);
}

line_bkp_05_26SAN::step103Activity::~step103Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step103Activity::LinkVariables(){


}

bool line_bkp_05_26SAN::step103Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec103->Mark()>0 && sec104->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step103Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step103Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step103Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step103Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step103Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step103Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step103Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step103Activity::Fire(){
  ;
  sec104->Mark()=sec103->Mark();
  return this;
}

/*======================step202Activity========================*/

line_bkp_05_26SAN::step202Activity::step202Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step202",6,Deterministic, RaceEnabled, 2,2, false);
}

line_bkp_05_26SAN::step202Activity::~step202Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step202Activity::LinkVariables(){


}

bool line_bkp_05_26SAN::step202Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec202->Mark()>0 && sec203->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step202Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step202Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step202Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step202Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step202Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step202Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step202Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step202Activity::Fire(){
  ;
  sec203->Mark()=sec202->Mark();
  return this;
}

/*======================step102Activity========================*/

line_bkp_05_26SAN::step102Activity::step102Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step102",7,Deterministic, RaceEnabled, 2,2, false);
}

line_bkp_05_26SAN::step102Activity::~step102Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step102Activity::LinkVariables(){


}

bool line_bkp_05_26SAN::step102Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec102->Mark()>0 && sec103->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step102Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step102Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step102Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step102Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step102Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step102Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step102Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step102Activity::Fire(){
  ;
  sec103->Mark()=sec102->Mark();
  return this;
}

/*======================step201Activity========================*/

line_bkp_05_26SAN::step201Activity::step201Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step201",8,Deterministic, RaceEnabled, 2,2, false);
}

line_bkp_05_26SAN::step201Activity::~step201Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step201Activity::LinkVariables(){


}

bool line_bkp_05_26SAN::step201Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec201->Mark()>0 && sec202->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step201Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step201Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step201Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step201Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step201Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step201Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step201Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step201Activity::Fire(){
  ;
  sec202->Mark()=sec201->Mark();
  return this;
}

/*======================step101Activity========================*/

line_bkp_05_26SAN::step101Activity::step101Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step101",9,Deterministic, RaceEnabled, 2,2, false);
}

line_bkp_05_26SAN::step101Activity::~step101Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step101Activity::LinkVariables(){


}

bool line_bkp_05_26SAN::step101Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec101->Mark()>0 && sec102->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step101Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step101Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step101Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step101Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step101Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step101Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step101Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step101Activity::Fire(){
  ;
  sec102->Mark()=sec101->Mark();
  return this;
}

/*======================step100Activity========================*/

line_bkp_05_26SAN::step100Activity::step100Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step100",10,Deterministic, RaceEnabled, 2,2, false);
}

line_bkp_05_26SAN::step100Activity::~step100Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step100Activity::LinkVariables(){


}

bool line_bkp_05_26SAN::step100Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec100->Mark()>0 && sec101->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step100Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step100Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step100Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step100Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step100Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step100Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step100Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step100Activity::Fire(){
  ;
  sec101->Mark()=sec100->Mark();
  return this;
}

/*======================arrivalFrom100Activity========================*/

line_bkp_05_26SAN::arrivalFrom100Activity::arrivalFrom100Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("arrivalFrom100",11,Deterministic, RaceEnabled, 2,0, false);
}

line_bkp_05_26SAN::arrivalFrom100Activity::~arrivalFrom100Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::arrivalFrom100Activity::LinkVariables(){


}

bool line_bkp_05_26SAN::arrivalFrom100Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(true);
  return NewEnabled;
}

double line_bkp_05_26SAN::arrivalFrom100Activity::DeterministicParamValue(){
  if(LastActionTime==0)
return 20;
else
return 10000;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::arrivalFrom100Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::arrivalFrom100Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::arrivalFrom100Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::arrivalFrom100Activity::SampleDistribution(){
  if(LastActionTime==0)
return 20;
else
return 10000;
}

double* line_bkp_05_26SAN::arrivalFrom100Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::arrivalFrom100Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::arrivalFrom100Activity::Fire(){
  if(sec100->Mark()==0){
	last_id1->Mark()++;
	sec100->Mark()=last_id1->Mark();
}
  return this;
}

/*======================step200Activity========================*/

line_bkp_05_26SAN::step200Activity::step200Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step200",12,Deterministic, RaceEnabled, 2,2, false);
}

line_bkp_05_26SAN::step200Activity::~step200Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step200Activity::LinkVariables(){


}

bool line_bkp_05_26SAN::step200Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec200->Mark()>0 && sec201->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step200Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step200Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step200Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step200Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step200Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step200Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step200Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step200Activity::Fire(){
  ;
  sec201->Mark()=sec200->Mark();
  return this;
}

/*======================arrivalFrom200Activity========================*/

line_bkp_05_26SAN::arrivalFrom200Activity::arrivalFrom200Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("arrivalFrom200",13,Deterministic, RaceEnabled, 2,0, false);
}

line_bkp_05_26SAN::arrivalFrom200Activity::~arrivalFrom200Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::arrivalFrom200Activity::LinkVariables(){


}

bool line_bkp_05_26SAN::arrivalFrom200Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(true);
  return NewEnabled;
}

double line_bkp_05_26SAN::arrivalFrom200Activity::DeterministicParamValue(){
  if(LastActionTime==0)
return 10000;
else
return 10000;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::arrivalFrom200Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::arrivalFrom200Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::arrivalFrom200Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::arrivalFrom200Activity::SampleDistribution(){
  if(LastActionTime==0)
return 10000;
else
return 10000;
}

double* line_bkp_05_26SAN::arrivalFrom200Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::arrivalFrom200Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::arrivalFrom200Activity::Fire(){
  if(sec200->Mark()==0){
	last_id2->Mark()++;
	sec200->Mark()=last_id2->Mark();
}
  return this;
}

/*======================step106Activity========================*/

line_bkp_05_26SAN::step106Activity::step106Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step106",14,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step106Activity::~step106Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step106Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step106Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec106->Mark()>0 && sec107->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step106Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step106Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step106Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step106Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step106Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step106Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step106Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step106Activity::Fire(){
  ;
  sec107->Mark()=sec106->Mark();

sec102->Mark()=0;
  return this;
}

/*======================step206Activity========================*/

line_bkp_05_26SAN::step206Activity::step206Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step206",15,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step206Activity::~step206Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step206Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step206Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec206->Mark()>0 && sec207->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step206Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step206Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step206Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step206Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step206Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step206Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step206Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step206Activity::Fire(){
  ;
  sec207->Mark()=sec206->Mark();

sec202->Mark()=0;
  return this;
}

/*======================step207Activity========================*/

line_bkp_05_26SAN::step207Activity::step207Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step207",16,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step207Activity::~step207Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step207Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step207Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec207->Mark()>0 && sec208->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step207Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step207Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step207Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step207Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step207Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step207Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step207Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step207Activity::Fire(){
  ;
  sec208->Mark()=sec207->Mark();

sec203->Mark()=0;
  return this;
}

/*======================step107Activity========================*/

line_bkp_05_26SAN::step107Activity::step107Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step107",17,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step107Activity::~step107Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step107Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step107Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec107->Mark()>0 && sec108->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step107Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step107Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step107Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step107Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step107Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step107Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step107Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step107Activity::Fire(){
  ;
  sec108->Mark()=sec107->Mark();

sec103->Mark()=0;
  return this;
}

/*======================step208Activity========================*/

line_bkp_05_26SAN::step208Activity::step208Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step208",18,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step208Activity::~step208Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step208Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step208Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec208->Mark()>0 && sec209->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step208Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step208Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step208Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step208Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step208Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step208Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step208Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step208Activity::Fire(){
  ;
  sec209->Mark()=sec208->Mark();

sec204->Mark()=0;
  return this;
}

/*======================step108Activity========================*/

line_bkp_05_26SAN::step108Activity::step108Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step108",19,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step108Activity::~step108Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step108Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step108Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec108->Mark()>0 && sec109->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step108Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step108Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step108Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step108Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step108Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step108Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step108Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step108Activity::Fire(){
  ;
  sec109->Mark()=sec108->Mark();

sec104->Mark()=0;
  return this;
}

/*======================step209Activity========================*/

line_bkp_05_26SAN::step209Activity::step209Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step209",20,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step209Activity::~step209Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step209Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step209Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec209->Mark()>0 && sec210->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step209Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step209Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step209Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step209Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step209Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step209Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step209Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step209Activity::Fire(){
  ;
  sec210->Mark()=sec209->Mark();

sec205->Mark()=0;
  return this;
}

/*======================step109Activity========================*/

line_bkp_05_26SAN::step109Activity::step109Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step109",21,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step109Activity::~step109Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step109Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step109Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec109->Mark()>0 && sec110->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step109Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step109Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step109Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step109Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step109Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step109Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step109Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step109Activity::Fire(){
  ;
  sec110->Mark()=sec109->Mark();

sec105->Mark()=0;
  return this;
}

/*======================step210Activity========================*/

line_bkp_05_26SAN::step210Activity::step210Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step210",22,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step210Activity::~step210Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step210Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step210Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec210->Mark()>0 && sec211->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step210Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step210Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step210Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step210Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step210Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step210Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step210Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step210Activity::Fire(){
  ;
  sec211->Mark()=sec210->Mark();

sec206->Mark()=0;
  return this;
}

/*======================step110Activity========================*/

line_bkp_05_26SAN::step110Activity::step110Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step110",23,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step110Activity::~step110Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step110Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step110Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec110->Mark()>0 && sec111->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step110Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step110Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step110Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step110Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step110Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step110Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step110Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step110Activity::Fire(){
  ;
  sec111->Mark()=sec110->Mark();

sec106->Mark()=0;
  return this;
}

/*======================step211Activity========================*/

line_bkp_05_26SAN::step211Activity::step211Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step211",24,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step211Activity::~step211Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step211Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step211Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec211->Mark()>0 && sec212->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step211Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step211Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step211Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step211Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step211Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step211Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step211Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step211Activity::Fire(){
  ;
  sec212->Mark()=sec211->Mark();

sec207->Mark()=0;
  return this;
}

/*======================step111Activity========================*/

line_bkp_05_26SAN::step111Activity::step111Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step111",25,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step111Activity::~step111Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step111Activity::LinkVariables(){




}

bool line_bkp_05_26SAN::step111Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec111->Mark()>0 && sec112->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step111Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step111Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step111Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step111Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step111Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step111Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step111Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step111Activity::Fire(){
  ;
  sec112->Mark()=sec110->Mark();

sec107->Mark()=0;
  return this;
}

/*======================step117Activity========================*/

line_bkp_05_26SAN::step117Activity::step117Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step117",26,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step117Activity::~step117Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step117Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step117Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec117->Mark()>0 && sec118->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step117Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step117Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step117Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step117Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step117Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step117Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step117Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step117Activity::Fire(){
  ;
  sec118->Mark()=sec117->Mark();

sec113->Mark()=0;
  return this;
}

/*======================step216Activity========================*/

line_bkp_05_26SAN::step216Activity::step216Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step216",27,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step216Activity::~step216Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step216Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step216Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec216->Mark()>0 && sec217->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step216Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step216Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step216Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step216Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step216Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step216Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step216Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step216Activity::Fire(){
  ;
  sec217->Mark()=sec216->Mark();

sec212->Mark()=0;
  return this;
}

/*======================step116Activity========================*/

line_bkp_05_26SAN::step116Activity::step116Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step116",28,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step116Activity::~step116Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step116Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step116Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec116->Mark()>0 && sec117->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step116Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step116Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step116Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step116Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step116Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step116Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step116Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step116Activity::Fire(){
  ;
  sec117->Mark()=sec116->Mark();

sec112->Mark()=0;
  return this;
}

/*======================step217Activity========================*/

line_bkp_05_26SAN::step217Activity::step217Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step217",29,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step217Activity::~step217Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step217Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step217Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec217->Mark()>0 && sec218->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step217Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step217Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step217Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step217Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step217Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step217Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step217Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step217Activity::Fire(){
  ;
  sec218->Mark()=sec217->Mark();

sec213->Mark()=0;
  return this;
}

/*======================step215Activity========================*/

line_bkp_05_26SAN::step215Activity::step215Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step215",30,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step215Activity::~step215Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step215Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step215Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec215->Mark()>0 && sec216->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step215Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step215Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step215Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step215Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step215Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step215Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step215Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step215Activity::Fire(){
  ;
  sec216->Mark()=sec215->Mark();

sec211->Mark()=0;
  return this;
}

/*======================step115Activity========================*/

line_bkp_05_26SAN::step115Activity::step115Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step115",31,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step115Activity::~step115Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step115Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step115Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec115->Mark()>0 && sec116->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step115Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step115Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step115Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step115Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step115Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step115Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step115Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step115Activity::Fire(){
  ;
  sec116->Mark()=sec115->Mark();

sec111->Mark()=0;
  return this;
}

/*======================step214Activity========================*/

line_bkp_05_26SAN::step214Activity::step214Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step214",32,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step214Activity::~step214Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step214Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step214Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec214->Mark()>0 && sec215->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step214Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step214Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step214Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step214Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step214Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step214Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step214Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step214Activity::Fire(){
  ;
  sec215->Mark()=sec214->Mark();

sec210->Mark()=0;
  return this;
}

/*======================step114Activity========================*/

line_bkp_05_26SAN::step114Activity::step114Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step114",33,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step114Activity::~step114Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step114Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step114Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec114->Mark()>0 && sec115->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step114Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step114Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step114Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step114Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step114Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step114Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step114Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step114Activity::Fire(){
  ;
  sec115->Mark()=sec114->Mark();

sec110->Mark()=0;
  return this;
}

/*======================step213Activity========================*/

line_bkp_05_26SAN::step213Activity::step213Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step213",34,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step213Activity::~step213Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step213Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step213Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec213->Mark()>0 && sec214->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step213Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step213Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step213Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step213Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step213Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step213Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step213Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step213Activity::Fire(){
  ;
  sec214->Mark()=sec213->Mark();

sec209->Mark()=0;
  return this;
}

/*======================step113Activity========================*/

line_bkp_05_26SAN::step113Activity::step113Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step113",35,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step113Activity::~step113Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step113Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step113Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec113->Mark()>0 && sec114->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step113Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step113Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step113Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step113Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step113Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step113Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step113Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step113Activity::Fire(){
  ;
  sec114->Mark()=sec113->Mark();

sec109->Mark()=0;
  return this;
}

/*======================step112Activity========================*/

line_bkp_05_26SAN::step112Activity::step112Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step112",36,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step112Activity::~step112Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step112Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step112Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec112->Mark()>0 && sec113->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step112Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step112Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step112Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step112Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step112Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step112Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step112Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step112Activity::Fire(){
  ;
  sec113->Mark()=sec112->Mark();

sec108->Mark()=0;
  return this;
}

/*======================step212Activity========================*/

line_bkp_05_26SAN::step212Activity::step212Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step212",37,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step212Activity::~step212Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step212Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step212Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec212->Mark()>0 && sec213->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step212Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step212Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step212Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step212Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step212Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step212Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step212Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step212Activity::Fire(){
  ;
  sec213->Mark()=sec212->Mark();

sec208->Mark()=0;
  return this;
}

/*======================step220Activity========================*/

line_bkp_05_26SAN::step220Activity::step220Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step220",38,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step220Activity::~step220Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step220Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step220Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec220->Mark()>0 && sec121->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step220Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step220Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step220Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step220Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step220Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step220Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step220Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step220Activity::Fire(){
  ;
  sec121->Mark()=sec220->Mark();

sec216->Mark()=0;
  return this;
}

/*======================step219Activity========================*/

line_bkp_05_26SAN::step219Activity::step219Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step219",39,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step219Activity::~step219Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step219Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step219Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec219->Mark()>0 && sec220->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step219Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step219Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step219Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step219Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step219Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step219Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step219Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step219Activity::Fire(){
  ;
  sec220->Mark()=sec219->Mark();

sec215->Mark()=0;
  return this;
}

/*======================step218Activity========================*/

line_bkp_05_26SAN::step218Activity::step218Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step218",40,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step218Activity::~step218Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step218Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step218Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec218->Mark()>0 && sec219->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step218Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step218Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step218Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step218Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step218Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step218Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step218Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step218Activity::Fire(){
  ;
  sec219->Mark()=sec218->Mark();

sec214->Mark()=0;
  return this;
}

/*======================step122Activity========================*/

line_bkp_05_26SAN::step122Activity::step122Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step122",41,Deterministic, RaceEnabled, 4,1, false);
}

line_bkp_05_26SAN::step122Activity::~step122Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step122Activity::LinkVariables(){




}

bool line_bkp_05_26SAN::step122Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((out122IP()));
  return NewEnabled;
}

    bool line_bkp_05_26SAN::step122Activity::out122IP(){
return (sec122->Mark()>0); //&& sec123->Mark()==0
return 0;
    }

double line_bkp_05_26SAN::step122Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step122Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step122Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step122Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step122Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step122Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step122Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step122Activity::Fire(){
  ;
  sec123->Mark()=sec122->Mark();

if(sec123->Mark()>10) {
sec218->Mark()=0;
} else {
sec118->Mark()=0;
}
  return this;
}

/*======================step121Activity========================*/

line_bkp_05_26SAN::step121Activity::step121Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step121",42,Deterministic, RaceEnabled, 4,2, false);
}

line_bkp_05_26SAN::step121Activity::~step121Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step121Activity::LinkVariables(){




}

bool line_bkp_05_26SAN::step121Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec121->Mark()>0 && sec122->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step121Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step121Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step121Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step121Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step121Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step121Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step121Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step121Activity::Fire(){
  ;
  sec122->Mark()=sec121->Mark();

if(sec122->Mark()>10) {
sec217->Mark()=0;
} else {
sec117->Mark()=0;
}

  return this;
}

/*======================step120Activity========================*/

line_bkp_05_26SAN::step120Activity::step120Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step120",43,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step120Activity::~step120Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step120Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step120Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec120->Mark()>0 && sec121->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step120Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step120Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step120Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step120Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step120Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step120Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step120Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step120Activity::Fire(){
  ;
  sec121->Mark()=sec120->Mark();

sec116->Mark()=0;
  return this;
}

/*======================step119Activity========================*/

line_bkp_05_26SAN::step119Activity::step119Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step119",44,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step119Activity::~step119Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step119Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step119Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec119->Mark()>0 && sec120->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step119Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step119Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step119Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step119Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step119Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step119Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step119Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step119Activity::Fire(){
  ;
  sec120->Mark()=sec119->Mark();

sec115->Mark()=0;
  return this;
}

/*======================step118Activity========================*/

line_bkp_05_26SAN::step118Activity::step118Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step118",45,Deterministic, RaceEnabled, 3,2, false);
}

line_bkp_05_26SAN::step118Activity::~step118Activity(){
  delete[] TheDistributionParameters;
}

void line_bkp_05_26SAN::step118Activity::LinkVariables(){



}

bool line_bkp_05_26SAN::step118Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((sec118->Mark()>0 && sec119->Mark()==0));
  return NewEnabled;
}

double line_bkp_05_26SAN::step118Activity::DeterministicParamValue(){
  return 20;
  return 1.0;  // default rate if none is specified
}

double line_bkp_05_26SAN::step118Activity::Weight(){ 
  return 1;
}

bool line_bkp_05_26SAN::step118Activity::ReactivationPredicate(){ 
  return false;
}

bool line_bkp_05_26SAN::step118Activity::ReactivationFunction(){ 
  return false;
}

double line_bkp_05_26SAN::step118Activity::SampleDistribution(){
  return 20;
}

double* line_bkp_05_26SAN::step118Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int line_bkp_05_26SAN::step118Activity::Rank(){
  return 1;
}

BaseActionClass* line_bkp_05_26SAN::step118Activity::Fire(){
  ;
  sec119->Mark()=sec118->Mark();

sec114->Mark()=0;
  return this;
}

