#ifndef line_bkp_05_26SAN_H_
#define line_bkp_05_26SAN_H_

#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern Short numOfTrains;
extern UserDistributions* TheDistribution;

void MemoryError();

#ifndef _TrainArray_header_
#define _TrainArray_header_

typedef short TrainArray_state;
class TrainArray: public ArrayStateVariable<ExtendedPlace<short> > {
  public:
  TrainArray(char* name, char* fullname):
    ArrayStateVariable<ExtendedPlace<short> >(name, fullname, ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, fqname));
    }
  }

  TrainArray(char* name):
    ArrayStateVariable<ExtendedPlace<short> >(name, "", ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, name));
    }
  }

  TrainArray(char* name, char* fullname, short & initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, fullname, ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, fqname, initialValue));
    }
  }

  TrainArray(char* name, short & initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, "", ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, name, initialValue));
    }
  }

  TrainArray(char* name, char* fullname, short * initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, fullname, ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, fqname, initialValue[i]));
    }
  }

  TrainArray(char* name, short * initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, "", ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, name, initialValue[i]));
    }
  }
  ~TrainArray() {
    for (fieldIterator i=fields.begin();i!=fields.end();++i)
      delete (*i);
  }
};
#endif

/*********************************************************************
               line_bkp_05_26SAN Submodel Definition                   
*********************************************************************/

class line_bkp_05_26SAN:public SANModel{
public:

class countingActivity:public Activity {
public:

  ExtendedPlace<short>* sec123;
  ExtendedPlace<short>* counter_LastId;
  ExtendedPlace<short>* counted;

  double* TheDistributionParameters;
  countingActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // countingActivityActivity

class step205Activity:public Activity {
public:

  ExtendedPlace<short>* sec205;
  ExtendedPlace<short>* sec206;
  ExtendedPlace<short>* sec201;

  double* TheDistributionParameters;
  step205Activity();
  ~step205Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step205ActivityActivity

class step105Activity:public Activity {
public:

  ExtendedPlace<short>* sec105;
  ExtendedPlace<short>* sec106;
  ExtendedPlace<short>* sec101;

  double* TheDistributionParameters;
  step105Activity();
  ~step105Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step105ActivityActivity

class step204Activity:public Activity {
public:

  ExtendedPlace<short>* sec204;
  ExtendedPlace<short>* sec205;
  ExtendedPlace<short>* sec200;

  double* TheDistributionParameters;
  step204Activity();
  ~step204Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step204ActivityActivity

class step104Activity:public Activity {
public:

  ExtendedPlace<short>* sec104;
  ExtendedPlace<short>* sec105;
  ExtendedPlace<short>* sec100;

  double* TheDistributionParameters;
  step104Activity();
  ~step104Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step104ActivityActivity

class step203Activity:public Activity {
public:

  ExtendedPlace<short>* sec203;
  ExtendedPlace<short>* sec204;

  double* TheDistributionParameters;
  step203Activity();
  ~step203Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step203ActivityActivity

class step103Activity:public Activity {
public:

  ExtendedPlace<short>* sec103;
  ExtendedPlace<short>* sec104;

  double* TheDistributionParameters;
  step103Activity();
  ~step103Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step103ActivityActivity

class step202Activity:public Activity {
public:

  ExtendedPlace<short>* sec202;
  ExtendedPlace<short>* sec203;

  double* TheDistributionParameters;
  step202Activity();
  ~step202Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step202ActivityActivity

class step102Activity:public Activity {
public:

  ExtendedPlace<short>* sec102;
  ExtendedPlace<short>* sec103;

  double* TheDistributionParameters;
  step102Activity();
  ~step102Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step102ActivityActivity

class step201Activity:public Activity {
public:

  ExtendedPlace<short>* sec201;
  ExtendedPlace<short>* sec202;

  double* TheDistributionParameters;
  step201Activity();
  ~step201Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step201ActivityActivity

class step101Activity:public Activity {
public:

  ExtendedPlace<short>* sec101;
  ExtendedPlace<short>* sec102;

  double* TheDistributionParameters;
  step101Activity();
  ~step101Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step101ActivityActivity

class step100Activity:public Activity {
public:

  ExtendedPlace<short>* sec100;
  ExtendedPlace<short>* sec101;

  double* TheDistributionParameters;
  step100Activity();
  ~step100Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step100ActivityActivity

class arrivalFrom100Activity:public Activity {
public:

  ExtendedPlace<short>* sec100;
  ExtendedPlace<short>* last_id1;

  double* TheDistributionParameters;
  arrivalFrom100Activity();
  ~arrivalFrom100Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // arrivalFrom100ActivityActivity

class step200Activity:public Activity {
public:

  ExtendedPlace<short>* sec200;
  ExtendedPlace<short>* sec201;

  double* TheDistributionParameters;
  step200Activity();
  ~step200Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step200ActivityActivity

class arrivalFrom200Activity:public Activity {
public:

  ExtendedPlace<short>* sec200;
  ExtendedPlace<short>* last_id2;

  double* TheDistributionParameters;
  arrivalFrom200Activity();
  ~arrivalFrom200Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // arrivalFrom200ActivityActivity

class step106Activity:public Activity {
public:

  ExtendedPlace<short>* sec106;
  ExtendedPlace<short>* sec107;
  ExtendedPlace<short>* sec102;

  double* TheDistributionParameters;
  step106Activity();
  ~step106Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step106ActivityActivity

class step206Activity:public Activity {
public:

  ExtendedPlace<short>* sec206;
  ExtendedPlace<short>* sec207;
  ExtendedPlace<short>* sec202;

  double* TheDistributionParameters;
  step206Activity();
  ~step206Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step206ActivityActivity

class step207Activity:public Activity {
public:

  ExtendedPlace<short>* sec207;
  ExtendedPlace<short>* sec208;
  ExtendedPlace<short>* sec203;

  double* TheDistributionParameters;
  step207Activity();
  ~step207Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step207ActivityActivity

class step107Activity:public Activity {
public:

  ExtendedPlace<short>* sec107;
  ExtendedPlace<short>* sec108;
  ExtendedPlace<short>* sec103;

  double* TheDistributionParameters;
  step107Activity();
  ~step107Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step107ActivityActivity

class step208Activity:public Activity {
public:

  ExtendedPlace<short>* sec208;
  ExtendedPlace<short>* sec209;
  ExtendedPlace<short>* sec204;

  double* TheDistributionParameters;
  step208Activity();
  ~step208Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step208ActivityActivity

class step108Activity:public Activity {
public:

  ExtendedPlace<short>* sec108;
  ExtendedPlace<short>* sec109;
  ExtendedPlace<short>* sec104;

  double* TheDistributionParameters;
  step108Activity();
  ~step108Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step108ActivityActivity

class step209Activity:public Activity {
public:

  ExtendedPlace<short>* sec209;
  ExtendedPlace<short>* sec210;
  ExtendedPlace<short>* sec205;

  double* TheDistributionParameters;
  step209Activity();
  ~step209Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step209ActivityActivity

class step109Activity:public Activity {
public:

  ExtendedPlace<short>* sec109;
  ExtendedPlace<short>* sec110;
  ExtendedPlace<short>* sec105;

  double* TheDistributionParameters;
  step109Activity();
  ~step109Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step109ActivityActivity

class step210Activity:public Activity {
public:

  ExtendedPlace<short>* sec210;
  ExtendedPlace<short>* sec211;
  ExtendedPlace<short>* sec206;

  double* TheDistributionParameters;
  step210Activity();
  ~step210Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step210ActivityActivity

class step110Activity:public Activity {
public:

  ExtendedPlace<short>* sec110;
  ExtendedPlace<short>* sec111;
  ExtendedPlace<short>* sec106;

  double* TheDistributionParameters;
  step110Activity();
  ~step110Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step110ActivityActivity

class step211Activity:public Activity {
public:

  ExtendedPlace<short>* sec211;
  ExtendedPlace<short>* sec212;
  ExtendedPlace<short>* sec207;

  double* TheDistributionParameters;
  step211Activity();
  ~step211Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step211ActivityActivity

class step111Activity:public Activity {
public:

  ExtendedPlace<short>* sec111;
  ExtendedPlace<short>* sec112;
  ExtendedPlace<short>* sec110;
  ExtendedPlace<short>* sec107;

  double* TheDistributionParameters;
  step111Activity();
  ~step111Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step111ActivityActivity

class step117Activity:public Activity {
public:

  ExtendedPlace<short>* sec117;
  ExtendedPlace<short>* sec118;
  ExtendedPlace<short>* sec113;

  double* TheDistributionParameters;
  step117Activity();
  ~step117Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step117ActivityActivity

class step216Activity:public Activity {
public:

  ExtendedPlace<short>* sec216;
  ExtendedPlace<short>* sec217;
  ExtendedPlace<short>* sec212;

  double* TheDistributionParameters;
  step216Activity();
  ~step216Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step216ActivityActivity

class step116Activity:public Activity {
public:

  ExtendedPlace<short>* sec116;
  ExtendedPlace<short>* sec117;
  ExtendedPlace<short>* sec112;

  double* TheDistributionParameters;
  step116Activity();
  ~step116Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step116ActivityActivity

class step217Activity:public Activity {
public:

  ExtendedPlace<short>* sec217;
  ExtendedPlace<short>* sec218;
  ExtendedPlace<short>* sec213;

  double* TheDistributionParameters;
  step217Activity();
  ~step217Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step217ActivityActivity

class step215Activity:public Activity {
public:

  ExtendedPlace<short>* sec215;
  ExtendedPlace<short>* sec216;
  ExtendedPlace<short>* sec211;

  double* TheDistributionParameters;
  step215Activity();
  ~step215Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step215ActivityActivity

class step115Activity:public Activity {
public:

  ExtendedPlace<short>* sec115;
  ExtendedPlace<short>* sec116;
  ExtendedPlace<short>* sec111;

  double* TheDistributionParameters;
  step115Activity();
  ~step115Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step115ActivityActivity

class step214Activity:public Activity {
public:

  ExtendedPlace<short>* sec214;
  ExtendedPlace<short>* sec215;
  ExtendedPlace<short>* sec210;

  double* TheDistributionParameters;
  step214Activity();
  ~step214Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step214ActivityActivity

class step114Activity:public Activity {
public:

  ExtendedPlace<short>* sec114;
  ExtendedPlace<short>* sec115;
  ExtendedPlace<short>* sec110;

  double* TheDistributionParameters;
  step114Activity();
  ~step114Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step114ActivityActivity

class step213Activity:public Activity {
public:

  ExtendedPlace<short>* sec213;
  ExtendedPlace<short>* sec214;
  ExtendedPlace<short>* sec209;

  double* TheDistributionParameters;
  step213Activity();
  ~step213Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step213ActivityActivity

class step113Activity:public Activity {
public:

  ExtendedPlace<short>* sec113;
  ExtendedPlace<short>* sec114;
  ExtendedPlace<short>* sec109;

  double* TheDistributionParameters;
  step113Activity();
  ~step113Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step113ActivityActivity

class step112Activity:public Activity {
public:

  ExtendedPlace<short>* sec112;
  ExtendedPlace<short>* sec113;
  ExtendedPlace<short>* sec108;

  double* TheDistributionParameters;
  step112Activity();
  ~step112Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step112ActivityActivity

class step212Activity:public Activity {
public:

  ExtendedPlace<short>* sec212;
  ExtendedPlace<short>* sec213;
  ExtendedPlace<short>* sec208;

  double* TheDistributionParameters;
  step212Activity();
  ~step212Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step212ActivityActivity

class step220Activity:public Activity {
public:

  ExtendedPlace<short>* sec220;
  ExtendedPlace<short>* sec121;
  ExtendedPlace<short>* sec216;

  double* TheDistributionParameters;
  step220Activity();
  ~step220Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step220ActivityActivity

class step219Activity:public Activity {
public:

  ExtendedPlace<short>* sec219;
  ExtendedPlace<short>* sec220;
  ExtendedPlace<short>* sec215;

  double* TheDistributionParameters;
  step219Activity();
  ~step219Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step219ActivityActivity

class step218Activity:public Activity {
public:

  ExtendedPlace<short>* sec218;
  ExtendedPlace<short>* sec219;
  ExtendedPlace<short>* sec214;

  double* TheDistributionParameters;
  step218Activity();
  ~step218Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step218ActivityActivity

class step122Activity:public Activity {
public:

  ExtendedPlace<short>* sec122;
  ExtendedPlace<short>* sec123;
  ExtendedPlace<short>* sec218;
  ExtendedPlace<short>* sec118;

  double* TheDistributionParameters;
  step122Activity();
  ~step122Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
 bool out122IP();
}; // step122ActivityActivity

class step121Activity:public Activity {
public:

  ExtendedPlace<short>* sec121;
  ExtendedPlace<short>* sec122;
  ExtendedPlace<short>* sec217;
  ExtendedPlace<short>* sec117;

  double* TheDistributionParameters;
  step121Activity();
  ~step121Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step121ActivityActivity

class step120Activity:public Activity {
public:

  ExtendedPlace<short>* sec120;
  ExtendedPlace<short>* sec121;
  ExtendedPlace<short>* sec116;

  double* TheDistributionParameters;
  step120Activity();
  ~step120Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step120ActivityActivity

class step119Activity:public Activity {
public:

  ExtendedPlace<short>* sec119;
  ExtendedPlace<short>* sec120;
  ExtendedPlace<short>* sec115;

  double* TheDistributionParameters;
  step119Activity();
  ~step119Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step119ActivityActivity

class step118Activity:public Activity {
public:

  ExtendedPlace<short>* sec118;
  ExtendedPlace<short>* sec119;
  ExtendedPlace<short>* sec114;

  double* TheDistributionParameters;
  step118Activity();
  ~step118Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step118ActivityActivity

  //List of user-specified place names
  ExtendedPlace<short>* sec206;
  ExtendedPlace<short>* sec106;
  ExtendedPlace<short>* sec205;
  ExtendedPlace<short>* sec105;
  ExtendedPlace<short>* sec204;
  ExtendedPlace<short>* sec104;
  ExtendedPlace<short>* sec203;
  ExtendedPlace<short>* sec103;
  ExtendedPlace<short>* sec202;
  ExtendedPlace<short>* sec102;
  ExtendedPlace<short>* sec201;
  ExtendedPlace<short>* sec101;
  TrainArray* trStates;
  ExtendedPlace<short>* sec100;
  ExtendedPlace<short>* sec200;
  ExtendedPlace<short>* last_id1;
  ExtendedPlace<short>* last_id2;
  ExtendedPlace<short>* sec207;
  ExtendedPlace<short>* sec107;
  ExtendedPlace<short>* sec208;
  ExtendedPlace<short>* sec108;
  ExtendedPlace<short>* sec209;
  ExtendedPlace<short>* sec109;
  ExtendedPlace<short>* sec210;
  ExtendedPlace<short>* sec110;
  ExtendedPlace<short>* sec211;
  ExtendedPlace<short>* sec111;
  ExtendedPlace<short>* sec212;
  ExtendedPlace<short>* sec112;
  ExtendedPlace<short>* sec118;
  ExtendedPlace<short>* sec117;
  ExtendedPlace<short>* sec217;
  ExtendedPlace<short>* sec218;
  ExtendedPlace<short>* sec216;
  ExtendedPlace<short>* sec116;
  ExtendedPlace<short>* sec215;
  ExtendedPlace<short>* sec115;
  ExtendedPlace<short>* sec214;
  ExtendedPlace<short>* sec114;
  ExtendedPlace<short>* sec213;
  ExtendedPlace<short>* sec113;
  ExtendedPlace<short>* sec220;
  ExtendedPlace<short>* sec219;
  ExtendedPlace<short>* sec123;
  ExtendedPlace<short>* sec122;
  ExtendedPlace<short>* sec121;
  ExtendedPlace<short>* sec120;
  ExtendedPlace<short>* sec119;
  ExtendedPlace<short>* counter_LastId;
  ExtendedPlace<short>* counted;

  // Create instances of all actvities
  countingActivity counting;
  step205Activity step205;
  step105Activity step105;
  step204Activity step204;
  step104Activity step104;
  step203Activity step203;
  step103Activity step103;
  step202Activity step202;
  step102Activity step102;
  step201Activity step201;
  step101Activity step101;
  step100Activity step100;
  arrivalFrom100Activity arrivalFrom100;
  step200Activity step200;
  arrivalFrom200Activity arrivalFrom200;
  step106Activity step106;
  step206Activity step206;
  step207Activity step207;
  step107Activity step107;
  step208Activity step208;
  step108Activity step108;
  step209Activity step209;
  step109Activity step109;
  step210Activity step210;
  step110Activity step110;
  step211Activity step211;
  step111Activity step111;
  step117Activity step117;
  step216Activity step216;
  step116Activity step116;
  step217Activity step217;
  step215Activity step215;
  step115Activity step115;
  step214Activity step214;
  step114Activity step114;
  step213Activity step213;
  step113Activity step113;
  step112Activity step112;
  step212Activity step212;
  step220Activity step220;
  step219Activity step219;
  step218Activity step218;
  step122Activity step122;
  step121Activity step121;
  step120Activity step120;
  step119Activity step119;
  step118Activity step118;
  //Create instances of all groups 
  PreselectGroup ImmediateGroup;
  PostselectGroup countingGroup;

  line_bkp_05_26SAN();
  ~line_bkp_05_26SAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end line_bkp_05_26SAN

#endif // line_bkp_05_26SAN_H_
