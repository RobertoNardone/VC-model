

// This C++ file was created by SanEditor

#include "Atomic/point/pointSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         pointSAN Constructor             
******************************************************************/


pointSAN::pointSAN(){


  Activity* InitialActionList[5]={
    &moveTrain1, //0
    &moveTrain2, //1
    &step1, //2
    &step2, //3
    &greenDelay  // 4
  };

  BaseGroupClass* InitialGroupList[5]={
    (BaseGroupClass*) &(step1), 
    (BaseGroupClass*) &(step2), 
    (BaseGroupClass*) &(greenDelay), 
    (BaseGroupClass*) &(moveTrain1), 
    (BaseGroupClass*) &(moveTrain2)
  };

  green = new Place("green" ,1);
  endTrain = new Place("endTrain" ,0);
  waitingTrain1 = new Place("waitingTrain1" ,0);
  waitingTrain2 = new Place("waitingTrain2" ,0);
  short temp_ERTMSstateshort = 0;
  ERTMSstate = new ExtendedPlace<short>("ERTMSstate",temp_ERTMSstateshort);
  short temp_secIn1short = 0;
  secIn1 = new ExtendedPlace<short>("secIn1",temp_secIn1short);
  short temp_secIn2short = 0;
  secIn2 = new ExtendedPlace<short>("secIn2",temp_secIn2short);
  short temp_secOutshort = 0;
  secOut = new ExtendedPlace<short>("secOut",temp_secOutshort);
  short temp_lastIdshort = 0;
  lastId = new ExtendedPlace<short>("lastId",temp_lastIdshort);
  BaseStateVariableClass* InitialPlaces[9]={
    green,  // 0
    endTrain,  // 1
    waitingTrain1,  // 2
    waitingTrain2,  // 3
    ERTMSstate,  // 4
    secIn1,  // 5
    secIn2,  // 6
    secOut,  // 7
    lastId   // 8
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("point", 9, InitialPlaces, 
                        0, InitialROPlaces, 
                        5, InitialActionList, 5, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[18][2]={ 
    {2,0}, {8,0}, {5,0}, {7,0}, {0,0}, {1,0}, {3,1}, {8,1}, {6,1}, 
    {7,1}, {0,1}, {1,1}, {0,2}, {2,2}, {0,3}, {3,3}, {1,4}, {0,4}
  };
  for(int n=0;n<18;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[11][2]={ 
    {2,0}, {7,0}, {3,1}, {7,1}, {0,2}, {5,2}, {2,2}, {0,3}, {6,3}, 
    {3,3}, {1,4}
  };
  for(int n=0;n<11;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<5;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void pointSAN::CustomInitialization() {

}
pointSAN::~pointSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void pointSAN::assignPlacesToActivitiesInst(){
  moveTrain1.waitingTrain1 = (Place*) LocalStateVariables[2];
  moveTrain1.secOut = (ExtendedPlace<short>*) LocalStateVariables[7];
  moveTrain1.lastId = (ExtendedPlace<short>*) LocalStateVariables[8];
  moveTrain1.secIn1 = (ExtendedPlace<short>*) LocalStateVariables[5];
  moveTrain1.green = (Place*) LocalStateVariables[0];
  moveTrain1.endTrain = (Place*) LocalStateVariables[1];
  moveTrain2.waitingTrain2 = (Place*) LocalStateVariables[3];
  moveTrain2.secOut = (ExtendedPlace<short>*) LocalStateVariables[7];
  moveTrain2.lastId = (ExtendedPlace<short>*) LocalStateVariables[8];
  moveTrain2.secIn2 = (ExtendedPlace<short>*) LocalStateVariables[6];
  moveTrain2.green = (Place*) LocalStateVariables[0];
  moveTrain2.endTrain = (Place*) LocalStateVariables[1];
}
void pointSAN::assignPlacesToActivitiesTimed(){
  step1.green = (Place*) LocalStateVariables[0];
  step1.secIn1 = (ExtendedPlace<short>*) LocalStateVariables[5];
  step1.waitingTrain1 = (Place*) LocalStateVariables[2];
  step1.ERTMSstate = (ExtendedPlace<short>*) LocalStateVariables[4];
  step2.green = (Place*) LocalStateVariables[0];
  step2.secIn2 = (ExtendedPlace<short>*) LocalStateVariables[6];
  step2.waitingTrain2 = (Place*) LocalStateVariables[3];
  step2.ERTMSstate = (ExtendedPlace<short>*) LocalStateVariables[4];
  greenDelay.endTrain = (Place*) LocalStateVariables[1];
  greenDelay.green = (Place*) LocalStateVariables[0];
  greenDelay.ERTMSstate = (ExtendedPlace<short>*) LocalStateVariables[4];
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================moveTrain1Activity========================*/


pointSAN::moveTrain1Activity::moveTrain1Activity(){
  ActivityInitialize("moveTrain1",3,Instantaneous , RaceEnabled, 6,2, false);
}

void pointSAN::moveTrain1Activity::LinkVariables(){
  waitingTrain1->Register(&waitingTrain1_Mobius_Mark);



  green->Register(&green_Mobius_Mark);
  endTrain->Register(&endTrain_Mobius_Mark);
}

bool pointSAN::moveTrain1Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(waitingTrain1_Mobius_Mark)) >=1)&&(secOut->Mark()==0));
  return NewEnabled;
}

double pointSAN::moveTrain1Activity::Weight(){ 
  return 1;
}

bool pointSAN::moveTrain1Activity::ReactivationPredicate(){ 
  return false;
}

bool pointSAN::moveTrain1Activity::ReactivationFunction(){ 
  return false;
}

double pointSAN::moveTrain1Activity::SampleDistribution(){
  return 0;
}

double* pointSAN::moveTrain1Activity::ReturnDistributionParameters(){
    return NULL;
}

int pointSAN::moveTrain1Activity::Rank(){
  return 1;
}

BaseActionClass* pointSAN::moveTrain1Activity::Fire(){
  ;
  (*(waitingTrain1_Mobius_Mark))--;
  if(lastId->Mark()=0 || secIn1->Mark()!=lastId->Mark()) {
	secOut->Mark()=secIn1->Mark();
	lastId->Mark()=secIn1->Mark();
	secIn1->Mark()=0;
	green->Mark()=1;
} else {
	endTrain->Mark()=1;
}
  return this;
}

/*======================moveTrain2Activity========================*/


pointSAN::moveTrain2Activity::moveTrain2Activity(){
  ActivityInitialize("moveTrain2",4,Instantaneous , RaceEnabled, 6,2, false);
}

void pointSAN::moveTrain2Activity::LinkVariables(){
  waitingTrain2->Register(&waitingTrain2_Mobius_Mark);



  green->Register(&green_Mobius_Mark);
  endTrain->Register(&endTrain_Mobius_Mark);
}

bool pointSAN::moveTrain2Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(waitingTrain2_Mobius_Mark)) >=1)&&(secOut->Mark()==0));
  return NewEnabled;
}

double pointSAN::moveTrain2Activity::Weight(){ 
  return 1;
}

bool pointSAN::moveTrain2Activity::ReactivationPredicate(){ 
  return false;
}

bool pointSAN::moveTrain2Activity::ReactivationFunction(){ 
  return false;
}

double pointSAN::moveTrain2Activity::SampleDistribution(){
  return 0;
}

double* pointSAN::moveTrain2Activity::ReturnDistributionParameters(){
    return NULL;
}

int pointSAN::moveTrain2Activity::Rank(){
  return 1;
}

BaseActionClass* pointSAN::moveTrain2Activity::Fire(){
  ;
  (*(waitingTrain2_Mobius_Mark))--;
  if(lastId->Mark()=0 || secIn2->Mark()!=lastId->Mark()) {
	secOut->Mark()=secIn2->Mark();
	lastId->Mark()=secIn2->Mark();
	secIn2->Mark()=0;
	green->Mark()=1;
} else {
	endTrain->Mark()=1;
}
  return this;
}

/*======================step1Activity========================*/

pointSAN::step1Activity::step1Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step1",0,Deterministic, RaceEnabled, 2,3, false);
}

pointSAN::step1Activity::~step1Activity(){
  delete[] TheDistributionParameters;
}

void pointSAN::step1Activity::LinkVariables(){
  green->Register(&green_Mobius_Mark);

  waitingTrain1->Register(&waitingTrain1_Mobius_Mark);

}

bool pointSAN::step1Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(green_Mobius_Mark)) >=1)&&(secIn1->Mark()>0 && waitingTrain1->Mark()==0));
  return NewEnabled;
}

double pointSAN::step1Activity::DeterministicParamValue(){
  if(ERTMSstate->Mark()!=3)
	return 20;
else 
	return 60;
  return 1.0;  // default rate if none is specified
}

double pointSAN::step1Activity::Weight(){ 
  return 1;
}

bool pointSAN::step1Activity::ReactivationPredicate(){ 
  return false;
}

bool pointSAN::step1Activity::ReactivationFunction(){ 
  return false;
}

double pointSAN::step1Activity::SampleDistribution(){
  if(ERTMSstate->Mark()!=3)
	return 20;
else 
	return 60;
}

double* pointSAN::step1Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int pointSAN::step1Activity::Rank(){
  return 1;
}

BaseActionClass* pointSAN::step1Activity::Fire(){
  ;
  (*(green_Mobius_Mark))--;
  (*(waitingTrain1_Mobius_Mark))++;
  return this;
}

/*======================step2Activity========================*/

pointSAN::step2Activity::step2Activity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step2",1,Deterministic, RaceEnabled, 2,3, false);
}

pointSAN::step2Activity::~step2Activity(){
  delete[] TheDistributionParameters;
}

void pointSAN::step2Activity::LinkVariables(){
  green->Register(&green_Mobius_Mark);

  waitingTrain2->Register(&waitingTrain2_Mobius_Mark);

}

bool pointSAN::step2Activity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(green_Mobius_Mark)) >=1)&&(secIn2->Mark()>0 && waitingTrain2->Mark()==0));
  return NewEnabled;
}

double pointSAN::step2Activity::DeterministicParamValue(){
  if(ERTMSstate->Mark()!=3)
	return 20;
else 
	return 60;
  return 1.0;  // default rate if none is specified
}

double pointSAN::step2Activity::Weight(){ 
  return 1;
}

bool pointSAN::step2Activity::ReactivationPredicate(){ 
  return false;
}

bool pointSAN::step2Activity::ReactivationFunction(){ 
  return false;
}

double pointSAN::step2Activity::SampleDistribution(){
  if(ERTMSstate->Mark()!=3)
	return 20;
else 
	return 60;
}

double* pointSAN::step2Activity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int pointSAN::step2Activity::Rank(){
  return 1;
}

BaseActionClass* pointSAN::step2Activity::Fire(){
  ;
  (*(green_Mobius_Mark))--;
  (*(waitingTrain2_Mobius_Mark))++;
  return this;
}

/*======================greenDelayActivity========================*/

pointSAN::greenDelayActivity::greenDelayActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("greenDelay",2,Deterministic, RaceEnabled, 2,1, false);
}

pointSAN::greenDelayActivity::~greenDelayActivity(){
  delete[] TheDistributionParameters;
}

void pointSAN::greenDelayActivity::LinkVariables(){
  endTrain->Register(&endTrain_Mobius_Mark);
  green->Register(&green_Mobius_Mark);

}

bool pointSAN::greenDelayActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(endTrain_Mobius_Mark)) >=1));
  return NewEnabled;
}

double pointSAN::greenDelayActivity::DeterministicParamValue(){
  if(ERTMSstate->Mark()==2)
	return FSDelay;
else 
	return 0;
  return 1.0;  // default rate if none is specified
}

double pointSAN::greenDelayActivity::Weight(){ 
  return 1;
}

bool pointSAN::greenDelayActivity::ReactivationPredicate(){ 
  return false;
}

bool pointSAN::greenDelayActivity::ReactivationFunction(){ 
  return false;
}

double pointSAN::greenDelayActivity::SampleDistribution(){
  if(ERTMSstate->Mark()==2)
	return FSDelay;
else 
	return 0;
}

double* pointSAN::greenDelayActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int pointSAN::greenDelayActivity::Rank(){
  return 1;
}

BaseActionClass* pointSAN::greenDelayActivity::Fire(){
  (*(endTrain_Mobius_Mark))--;
  (*(green_Mobius_Mark))++;
  return this;
}

