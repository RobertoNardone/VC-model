#ifndef pointSAN_H_
#define pointSAN_H_

#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern Short FSDelay;
extern UserDistributions* TheDistribution;

void MemoryError();


/*********************************************************************
               pointSAN Submodel Definition                   
*********************************************************************/

class pointSAN:public SANModel{
public:

class moveTrain1Activity:public Activity {
public:

  Place* waitingTrain1;
  short* waitingTrain1_Mobius_Mark;
  ExtendedPlace<short>* secOut;
  ExtendedPlace<short>* lastId;
  ExtendedPlace<short>* secIn1;
  Place* green;
  short* green_Mobius_Mark;
  Place* endTrain;
  short* endTrain_Mobius_Mark;

  double* TheDistributionParameters;
  moveTrain1Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // moveTrain1ActivityActivity

class moveTrain2Activity:public Activity {
public:

  Place* waitingTrain2;
  short* waitingTrain2_Mobius_Mark;
  ExtendedPlace<short>* secOut;
  ExtendedPlace<short>* lastId;
  ExtendedPlace<short>* secIn2;
  Place* green;
  short* green_Mobius_Mark;
  Place* endTrain;
  short* endTrain_Mobius_Mark;

  double* TheDistributionParameters;
  moveTrain2Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // moveTrain2ActivityActivity

class step1Activity:public Activity {
public:

  Place* green;
  short* green_Mobius_Mark;
  ExtendedPlace<short>* secIn1;
  Place* waitingTrain1;
  short* waitingTrain1_Mobius_Mark;
  ExtendedPlace<short>* ERTMSstate;

  double* TheDistributionParameters;
  step1Activity();
  ~step1Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step1ActivityActivity

class step2Activity:public Activity {
public:

  Place* green;
  short* green_Mobius_Mark;
  ExtendedPlace<short>* secIn2;
  Place* waitingTrain2;
  short* waitingTrain2_Mobius_Mark;
  ExtendedPlace<short>* ERTMSstate;

  double* TheDistributionParameters;
  step2Activity();
  ~step2Activity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // step2ActivityActivity

class greenDelayActivity:public Activity {
public:

  Place* endTrain;
  short* endTrain_Mobius_Mark;
  Place* green;
  short* green_Mobius_Mark;
  ExtendedPlace<short>* ERTMSstate;

  double* TheDistributionParameters;
  greenDelayActivity();
  ~greenDelayActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // greenDelayActivityActivity

  //List of user-specified place names
  Place* green;
  Place* endTrain;
  Place* waitingTrain1;
  Place* waitingTrain2;
  ExtendedPlace<short>* ERTMSstate;
  ExtendedPlace<short>* secIn1;
  ExtendedPlace<short>* secIn2;
  ExtendedPlace<short>* secOut;
  ExtendedPlace<short>* lastId;

  // Create instances of all actvities
  moveTrain1Activity moveTrain1;
  moveTrain2Activity moveTrain2;
  step1Activity step1;
  step2Activity step2;
  greenDelayActivity greenDelay;
  //Create instances of all groups 
  PreselectGroup ImmediateGroup;
  PostselectGroup moveTrain1Group;
  PostselectGroup moveTrain2Group;

  pointSAN();
  ~pointSAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end pointSAN

#endif // pointSAN_H_
