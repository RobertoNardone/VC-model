

// This C++ file was created by SanEditor

#include "Atomic/straight/straightSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         straightSAN Constructor             
******************************************************************/


straightSAN::straightSAN(){


  Activity* InitialActionList[3]={
    &moveTrain, //0
    &step, //1
    &greenDelay  // 2
  };

  BaseGroupClass* InitialGroupList[3]={
    (BaseGroupClass*) &(step), 
    (BaseGroupClass*) &(greenDelay), 
    (BaseGroupClass*) &(moveTrain)
  };

  waitingTrain = new Place("waitingTrain" ,0);
  green = new Place("green" ,1);
  endTrain = new Place("endTrain" ,0);
  short temp_secInshort = 0;
  secIn = new ExtendedPlace<short>("secIn",temp_secInshort);
  short temp_secOutshort = 0;
  secOut = new ExtendedPlace<short>("secOut",temp_secOutshort);
  short temp_ERTMSstateshort = 1;
  ERTMSstate = new ExtendedPlace<short>("ERTMSstate",temp_ERTMSstateshort);
  short temp_lastIdshort = 0;
  lastId = new ExtendedPlace<short>("lastId",temp_lastIdshort);
  BaseStateVariableClass* InitialPlaces[7]={
    waitingTrain,  // 0
    green,  // 1
    endTrain,  // 2
    secIn,  // 3
    secOut,  // 4
    ERTMSstate,  // 5
    lastId   // 6
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("straight", 7, InitialPlaces, 
                        0, InitialROPlaces, 
                        3, InitialActionList, 3, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[10][2]={ 
    {0,0}, {6,0}, {3,0}, {1,0}, {4,0}, {2,0}, {1,1}, {0,1}, {2,2}, 
    {1,2}
  };
  for(int n=0;n<10;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[6][2]={ 
    {0,0}, {4,0}, {1,1}, {3,1}, {0,1}, {2,2}
  };
  for(int n=0;n<6;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<3;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void straightSAN::CustomInitialization() {

}
straightSAN::~straightSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void straightSAN::assignPlacesToActivitiesInst(){
  moveTrain.waitingTrain = (Place*) LocalStateVariables[0];
  moveTrain.secOut = (ExtendedPlace<short>*) LocalStateVariables[4];
  moveTrain.lastId = (ExtendedPlace<short>*) LocalStateVariables[6];
  moveTrain.secIn = (ExtendedPlace<short>*) LocalStateVariables[3];
  moveTrain.green = (Place*) LocalStateVariables[1];
  moveTrain.endTrain = (Place*) LocalStateVariables[2];
}
void straightSAN::assignPlacesToActivitiesTimed(){
  step.green = (Place*) LocalStateVariables[1];
  step.secIn = (ExtendedPlace<short>*) LocalStateVariables[3];
  step.waitingTrain = (Place*) LocalStateVariables[0];
  step.ERTMSstate = (ExtendedPlace<short>*) LocalStateVariables[5];
  greenDelay.endTrain = (Place*) LocalStateVariables[2];
  greenDelay.green = (Place*) LocalStateVariables[1];
  greenDelay.ERTMSstate = (ExtendedPlace<short>*) LocalStateVariables[5];
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================moveTrainActivity========================*/


straightSAN::moveTrainActivity::moveTrainActivity(){
  ActivityInitialize("moveTrain",2,Instantaneous , RaceEnabled, 6,2, false);
}

void straightSAN::moveTrainActivity::LinkVariables(){
  waitingTrain->Register(&waitingTrain_Mobius_Mark);



  green->Register(&green_Mobius_Mark);
  endTrain->Register(&endTrain_Mobius_Mark);
}

bool straightSAN::moveTrainActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(waitingTrain_Mobius_Mark)) >=1)&&(secOut->Mark()==0));
  return NewEnabled;
}

double straightSAN::moveTrainActivity::Weight(){ 
  return 1;
}

bool straightSAN::moveTrainActivity::ReactivationPredicate(){ 
  return false;
}

bool straightSAN::moveTrainActivity::ReactivationFunction(){ 
  return false;
}

double straightSAN::moveTrainActivity::SampleDistribution(){
  return 0;
}

double* straightSAN::moveTrainActivity::ReturnDistributionParameters(){
    return NULL;
}

int straightSAN::moveTrainActivity::Rank(){
  return 1;
}

BaseActionClass* straightSAN::moveTrainActivity::Fire(){
  ;
  (*(waitingTrain_Mobius_Mark))--;
  if(lastId->Mark()==0 || secIn->Mark()==lastId->Mark()) {	
	green->Mark()=1;
	secOut->Mark()=secIn->Mark();
	lastId->Mark()=secIn->Mark();
	secIn->Mark()=0;
} else {
	endTrain->Mark()=1;
	secOut->Mark()=0;
	lastId->Mark()=secIn->Mark();
}

  return this;
}

/*======================stepActivity========================*/

straightSAN::stepActivity::stepActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("step",0,Deterministic, RaceEnabled, 2,3, false);
}

straightSAN::stepActivity::~stepActivity(){
  delete[] TheDistributionParameters;
}

void straightSAN::stepActivity::LinkVariables(){
  green->Register(&green_Mobius_Mark);

  waitingTrain->Register(&waitingTrain_Mobius_Mark);

}

bool straightSAN::stepActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(green_Mobius_Mark)) >=1)&&(secIn->Mark()>0 && waitingTrain->Mark()==0));
  return NewEnabled;
}

double straightSAN::stepActivity::DeterministicParamValue(){
  /*if(ERTMSstate->Mark()!=3)
	return 20;
else 
	return 60;*/
//
if(ERTMSstate->Mark()!=3)
	return 8;
else 
	return 24;
  return 1.0;  // default rate if none is specified
}

double straightSAN::stepActivity::Weight(){ 
  return 1;
}

bool straightSAN::stepActivity::ReactivationPredicate(){ 
  return false;
}

bool straightSAN::stepActivity::ReactivationFunction(){ 
  return false;
}

double straightSAN::stepActivity::SampleDistribution(){
  /*if(ERTMSstate->Mark()!=3)
	return 20;
else 
	return 60;*/
//
if(ERTMSstate->Mark()!=3)
	return 8;
else 
	return 24;
}

double* straightSAN::stepActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int straightSAN::stepActivity::Rank(){
  return 1;
}

BaseActionClass* straightSAN::stepActivity::Fire(){
  ;
  (*(green_Mobius_Mark))--;
  (*(waitingTrain_Mobius_Mark))++;
  return this;
}

/*======================greenDelayActivity========================*/

straightSAN::greenDelayActivity::greenDelayActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("greenDelay",1,Deterministic, RaceEnabled, 2,1, false);
}

straightSAN::greenDelayActivity::~greenDelayActivity(){
  delete[] TheDistributionParameters;
}

void straightSAN::greenDelayActivity::LinkVariables(){
  endTrain->Register(&endTrain_Mobius_Mark);
  green->Register(&green_Mobius_Mark);

}

bool straightSAN::greenDelayActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(endTrain_Mobius_Mark)) >=1));
  return NewEnabled;
}

double straightSAN::greenDelayActivity::DeterministicParamValue(){
  if(ERTMSstate->Mark()==2)
	return FSDelay-8;
else 
	return 0;
  return 1.0;  // default rate if none is specified
}

double straightSAN::greenDelayActivity::Weight(){ 
  return 1;
}

bool straightSAN::greenDelayActivity::ReactivationPredicate(){ 
  return false;
}

bool straightSAN::greenDelayActivity::ReactivationFunction(){ 
  return false;
}

double straightSAN::greenDelayActivity::SampleDistribution(){
  if(ERTMSstate->Mark()==2)
	return FSDelay-8;
else 
	return 0;
}

double* straightSAN::greenDelayActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int straightSAN::greenDelayActivity::Rank(){
  return 1;
}

BaseActionClass* straightSAN::greenDelayActivity::Fire(){
  (*(endTrain_Mobius_Mark))--;
  (*(green_Mobius_Mark))++;
  return this;
}

