#ifndef straightSAN_H_
#define straightSAN_H_

#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern Short numOfTrains;
extern Short trainLength;
extern Short FSDelay;
extern UserDistributions* TheDistribution;

void MemoryError();

#ifndef _TrainArray_header_
#define _TrainArray_header_

typedef short TrainArray_state;
class TrainArray: public ArrayStateVariable<ExtendedPlace<short> > {
  public:
  TrainArray(char* name, char* fullname):
    ArrayStateVariable<ExtendedPlace<short> >(name, fullname, ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, fqname));
    }
  }

  TrainArray(char* name):
    ArrayStateVariable<ExtendedPlace<short> >(name, "", ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, name));
    }
  }

  TrainArray(char* name, char* fullname, short & initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, fullname, ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, fqname, initialValue));
    }
  }

  TrainArray(char* name, short & initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, "", ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, name, initialValue));
    }
  }

  TrainArray(char* name, char* fullname, short * initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, fullname, ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, fqname, initialValue[i]));
    }
  }

  TrainArray(char* name, short * initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, "", ArrayType_SHORT ,numOfTrains) {
    char varname[12];
    for (int i=0;i<numOfTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, name, initialValue[i]));
    }
  }
  ~TrainArray() {
    for (fieldIterator i=fields.begin();i!=fields.end();++i)
      delete (*i);
  }
};
#endif

/*********************************************************************
               straightSAN Submodel Definition                   
*********************************************************************/

class straightSAN:public SANModel{
public:

class moveTrainActivity:public Activity {
public:

  Place* waitingTrain;
  short* waitingTrain_Mobius_Mark;
  ExtendedPlace<short>* secOut;
  ExtendedPlace<short>* lastId;
  ExtendedPlace<short>* secIn;
  Place* green;
  short* green_Mobius_Mark;
  Place* endTrain;
  short* endTrain_Mobius_Mark;

  double* TheDistributionParameters;
  moveTrainActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // moveTrainActivityActivity

class stepActivity:public Activity {
public:

  Place* green;
  short* green_Mobius_Mark;
  ExtendedPlace<short>* secIn;
  Place* waitingTrain;
  short* waitingTrain_Mobius_Mark;
  ExtendedPlace<short>* ERTMSstate;

  double* TheDistributionParameters;
  stepActivity();
  ~stepActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // stepActivityActivity

class greenDelayActivity:public Activity {
public:

  Place* endTrain;
  short* endTrain_Mobius_Mark;
  Place* green;
  short* green_Mobius_Mark;
  ExtendedPlace<short>* ERTMSstate;

  double* TheDistributionParameters;
  greenDelayActivity();
  ~greenDelayActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // greenDelayActivityActivity

  //List of user-specified place names
  Place* waitingTrain;
  Place* green;
  Place* endTrain;
  ExtendedPlace<short>* secIn;
  ExtendedPlace<short>* secOut;
  ExtendedPlace<short>* ERTMSstate;
  ExtendedPlace<short>* lastId;

  // Create instances of all actvities
  moveTrainActivity moveTrain;
  stepActivity step;
  greenDelayActivity greenDelay;
  //Create instances of all groups 
  PreselectGroup ImmediateGroup;
  PostselectGroup moveTrainGroup;

  straightSAN();
  ~straightSAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end straightSAN

#endif // straightSAN_H_
