

// This C++ file was created by SanEditor

#include "Atomic/entering/enteringSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         enteringSAN Constructor             
******************************************************************/


enteringSAN::enteringSAN(){


  Activity* InitialActionList[3]={
    &newTrain, //0
    &contTrain, //1
    &arrivalTime  // 2
  };

  BaseGroupClass* InitialGroupList[3]={
    (BaseGroupClass*) &(arrivalTime), 
    (BaseGroupClass*) &(newTrain), 
    (BaseGroupClass*) &(contTrain)
  };

  waitingTrains = new Place("waitingTrains" ,1);
  short temp_lengthshort = 0;
  length = new ExtendedPlace<short>("length",temp_lengthshort);
  short temp_secOutshort = 0;
  secOut = new ExtendedPlace<short>("secOut",temp_secOutshort);
  short temp_lastIdshort = 0;
  lastId = new ExtendedPlace<short>("lastId",temp_lastIdshort);
  BaseStateVariableClass* InitialPlaces[4]={
    waitingTrains,  // 0
    length,  // 1
    secOut,  // 2
    lastId   // 3
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("entering", 4, InitialPlaces, 
                        0, InitialROPlaces, 
                        3, InitialActionList, 3, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[7][2]={ 
    {3,0}, {2,0}, {1,0}, {2,1}, {3,1}, {1,1}, {0,2}
  };
  for(int n=0;n<7;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[5][2]={ 
    {0,0}, {2,0}, {1,0}, {2,1}, {1,1}
  };
  for(int n=0;n<5;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<3;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void enteringSAN::CustomInitialization() {

}
enteringSAN::~enteringSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void enteringSAN::assignPlacesToActivitiesInst(){
  newTrain.waitingTrains = (Place*) LocalStateVariables[0];
  newTrain.secOut = (ExtendedPlace<short>*) LocalStateVariables[2];
  newTrain.length = (ExtendedPlace<short>*) LocalStateVariables[1];
  newTrain.lastId = (ExtendedPlace<short>*) LocalStateVariables[3];
  contTrain.secOut = (ExtendedPlace<short>*) LocalStateVariables[2];
  contTrain.length = (ExtendedPlace<short>*) LocalStateVariables[1];
  contTrain.lastId = (ExtendedPlace<short>*) LocalStateVariables[3];
}
void enteringSAN::assignPlacesToActivitiesTimed(){
  arrivalTime.waitingTrains = (Place*) LocalStateVariables[0];
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================newTrainActivity========================*/


enteringSAN::newTrainActivity::newTrainActivity(){
  ActivityInitialize("newTrain",1,Instantaneous , RaceEnabled, 3,3, false);
}

void enteringSAN::newTrainActivity::LinkVariables(){
  waitingTrains->Register(&waitingTrains_Mobius_Mark);



}

bool enteringSAN::newTrainActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((waitingTrains->Mark()>0 && secOut->Mark()==0 && length->Mark()==0));
  return NewEnabled;
}

double enteringSAN::newTrainActivity::Weight(){ 
  return 1;
}

bool enteringSAN::newTrainActivity::ReactivationPredicate(){ 
  return false;
}

bool enteringSAN::newTrainActivity::ReactivationFunction(){ 
  return false;
}

double enteringSAN::newTrainActivity::SampleDistribution(){
  return 0;
}

double* enteringSAN::newTrainActivity::ReturnDistributionParameters(){
    return NULL;
}

int enteringSAN::newTrainActivity::Rank(){
  return 1;
}

BaseActionClass* enteringSAN::newTrainActivity::Fire(){
  //waitingTrains->Mark()--;
;
  lastId->Mark()++;
if(lastId->Mark()>numOfTrains)
	lastId->Mark()=1;

secOut->Mark()=lastId->Mark();
length->Mark()=trainLength;
  return this;
}

/*======================contTrainActivity========================*/


enteringSAN::contTrainActivity::contTrainActivity(){
  ActivityInitialize("contTrain",2,Instantaneous , RaceEnabled, 3,2, false);
}

void enteringSAN::contTrainActivity::LinkVariables(){



}

bool enteringSAN::contTrainActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((secOut->Mark()==0 && length->Mark()>0));
  return NewEnabled;
}

double enteringSAN::contTrainActivity::Weight(){ 
  return 1;
}

bool enteringSAN::contTrainActivity::ReactivationPredicate(){ 
  return false;
}

bool enteringSAN::contTrainActivity::ReactivationFunction(){ 
  return false;
}

double enteringSAN::contTrainActivity::SampleDistribution(){
  return 0;
}

double* enteringSAN::contTrainActivity::ReturnDistributionParameters(){
    return NULL;
}

int enteringSAN::contTrainActivity::Rank(){
  return 1;
}

BaseActionClass* enteringSAN::contTrainActivity::Fire(){
  ;
  secOut->Mark()=lastId->Mark();
length->Mark()--;
  return this;
}

/*======================arrivalTimeActivity========================*/

enteringSAN::arrivalTimeActivity::arrivalTimeActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("arrivalTime",0,Deterministic, RaceEnabled, 1,0, false);
}

enteringSAN::arrivalTimeActivity::~arrivalTimeActivity(){
  delete[] TheDistributionParameters;
}

void enteringSAN::arrivalTimeActivity::LinkVariables(){
  waitingTrains->Register(&waitingTrains_Mobius_Mark);
}

bool enteringSAN::arrivalTimeActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(true);
  return NewEnabled;
}

double enteringSAN::arrivalTimeActivity::DeterministicParamValue(){
  /*if(LastActionTime==0)
return 43200;*/
return 2000000000000000000000000000;
  return 1.0;  // default rate if none is specified
}

double enteringSAN::arrivalTimeActivity::Weight(){ 
  return 1;
}

bool enteringSAN::arrivalTimeActivity::ReactivationPredicate(){ 
  return false;
}

bool enteringSAN::arrivalTimeActivity::ReactivationFunction(){ 
  return false;
}

double enteringSAN::arrivalTimeActivity::SampleDistribution(){
  /*if(LastActionTime==0)
return 43200;*/
return 2000000000000000000000000000;
}

double* enteringSAN::arrivalTimeActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int enteringSAN::arrivalTimeActivity::Rank(){
  return 1;
}

BaseActionClass* enteringSAN::arrivalTimeActivity::Fire(){
  (*(waitingTrains_Mobius_Mark))++;
  return this;
}

