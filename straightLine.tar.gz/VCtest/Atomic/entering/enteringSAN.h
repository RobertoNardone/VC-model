#ifndef enteringSAN_H_
#define enteringSAN_H_

#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern Short numOfTrains;
extern Short trainLength;
extern UserDistributions* TheDistribution;

void MemoryError();


/*********************************************************************
               enteringSAN Submodel Definition                   
*********************************************************************/

class enteringSAN:public SANModel{
public:

class newTrainActivity:public Activity {
public:

  Place* waitingTrains;
  short* waitingTrains_Mobius_Mark;
  ExtendedPlace<short>* secOut;
  ExtendedPlace<short>* length;
  ExtendedPlace<short>* lastId;

  double* TheDistributionParameters;
  newTrainActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // newTrainActivityActivity

class contTrainActivity:public Activity {
public:

  ExtendedPlace<short>* secOut;
  ExtendedPlace<short>* length;
  ExtendedPlace<short>* lastId;

  double* TheDistributionParameters;
  contTrainActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // contTrainActivityActivity

class arrivalTimeActivity:public Activity {
public:

  Place* waitingTrains;
  short* waitingTrains_Mobius_Mark;

  double* TheDistributionParameters;
  arrivalTimeActivity();
  ~arrivalTimeActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // arrivalTimeActivityActivity

  //List of user-specified place names
  Place* waitingTrains;
  ExtendedPlace<short>* length;
  ExtendedPlace<short>* secOut;
  ExtendedPlace<short>* lastId;

  // Create instances of all actvities
  newTrainActivity newTrain;
  contTrainActivity contTrain;
  arrivalTimeActivity arrivalTime;
  //Create instances of all groups 
  PreselectGroup ImmediateGroup;
  PostselectGroup newTrainGroup;
  PostselectGroup contTrainGroup;

  enteringSAN();
  ~enteringSAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end enteringSAN

#endif // enteringSAN_H_
